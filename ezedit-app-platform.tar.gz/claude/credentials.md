# JARVIS Credential Management System

**Document Version:** 2.0  
**Last Updated:** 2025-07-14  
**Classification:** CONFIDENTIAL  
**Owner:** James Strickland  
**Backup Location:** credentials.md.backup.YYYYMMDD_HHMMSS

---

## Table of Contents

1. [Security Guidelines](#security-guidelines)
2. [Cloud Infrastructure](#cloud-infrastructure)
3. [AI & Machine Learning Services](#ai--machine-learning-services)
4. [Payment Processing](#payment-processing)
5. [Web Services & APIs](#web-services--apis)
6. [Domain & DNS Management](#domain--dns-management)
7. [Communication Services](#communication-services)
8. [Version Control](#version-control)
9. [Third-Party APIs](#third-party-apis)
10. [Backup & Recovery](#backup--recovery)
11. [Rotation Schedule](#rotation-schedule)

---

## Security Guidelines

### Critical Security Notes:
- **NEVER** commit credentials to version control
- **ALWAYS** use environment variables in production
- **ROTATE** credentials regularly per schedule below
- **MONITOR** for unauthorized access
- **ENCRYPT** this file when storing externally

### Access Levels:
- **PRODUCTION:** Full access to live systems
- **DEVELOPMENT:** Limited access for testing
- **READ-ONLY:** Query access only
- **ADMIN:** Full administrative privileges

---

## Cloud Infrastructure

### Supabase Database Service
**Service Category:** Database/Backend-as-a-Service  
**Environment:** Production  
**Access Level:** ADMIN  
**Created:** 2024-01-03  
**Last Rotated:** 2024-01-03  
**Next Rotation:** 2025-01-03  

**Public Key (Anonymous Access):**
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNjdHN5a2djZmtoYWRvd3lnY3JqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE1OTE5MDUsImV4cCI6MjA2NzE2NzkwNX0.8cpoEx0MXO0kkTqDrpkbYRhXQHVQ0bmjHA0xI2rUWqY
```

**Secret Key (Service Role):**
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNjdHN5a2djZmtoYWRvd3lnY3JqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MTU5MTkwNSwiZXhwIjoyMDY3MTY3OTA1fQ.LZO9ckLrpeSFGf1Av0v9bFqpSP8dcQllrFJ-yHGAZdo
```

**Purpose:** Primary database for JARVIS system, user authentication, and data storage  
**Usage Context:** Server-side applications only  
**Security Notes:** Service role key provides full database access - use with extreme caution

---

### Digital Ocean Cloud Infrastructure
**Service Category:** Cloud Computing/VPS  
**Environment:** Production  
**Access Level:** ADMIN  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
dop_v1_f5fb7c9657fa9470aec45e4f40907bf5fa41bdba0eab928704be54d2368995c4
```

**Account Password:**
```
MattKaylaS2two
```

**Purpose:** Hosting droplets, databases, and deployment infrastructure  
**Access Scope:** Full account access  
**Security Notes:** API key has full account privileges - monitor usage regularly

---

### Netlify Web Hosting
**Service Category:** Static Site Hosting/CDN  
**Environment:** Production  
**Access Level:** ADMIN  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
nfp_wcCV8mNF2uxwHt9FZSqvEGKGpxobXhKr515d
```

**Purpose:** Static site deployment and hosting  
**Usage Context:** CI/CD deployment pipelines  
**Security Notes:** Provides full site deployment access

---

### Cloudflare CDN/DNS
**Service Category:** CDN/DNS/Security  
**Environment:** Production  
**Access Level:** ADMIN  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
x2y2DSl1CJAc0ZkzhLoX1hREs-dSdpReEnoVl3SA
```

**Purpose:** DNS management, CDN, and security services  
**Usage Context:** Domain configuration and performance optimization  
**Security Notes:** Global API key - consider using zone-specific tokens

---

## AI & Machine Learning Services

### OpenAI API
**Service Category:** AI/Language Models  
**Environment:** Production  
**Access Level:** PRODUCTION  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
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
```

**Purpose:** GPT models for text generation and AI functionality  
**Usage Context:** JARVIS core AI features  
**Rate Limits:** Monitor usage to avoid overage charges  
**Security Notes:** Project-scoped key - regularly monitor usage

---

### Anthropic Claude API
**Service Category:** AI/Language Models  
**Environment:** Production  
**Access Level:** PRODUCTION  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**Primary API Key:**
```
apikey_01Rj2N8SVvo6BePZj99NhmiT
```

**Secondary API Key:**
```
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
```

**Purpose:** Claude AI model access for advanced reasoning  
**Usage Context:** Alternative AI provider for JARVIS  
**Security Notes:** Two keys for redundancy - rotate independently

---

### Pinecone Vector Database
**Service Category:** Vector Database/ML  
**Environment:** Production  
**Access Level:** ADMIN  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
pcsk_7HZPkt_4Ckha1UaPZcnoL9adfKwiCTk1vJDD2wPi7Qw2SV5m3X65tYDpHK1H57RZbs9H51
```

**Purpose:** Vector embeddings storage for AI memory and search  
**Usage Context:** JARVIS memory system and semantic search  
**Security Notes:** Contains sensitive embedding data - secure transmission required

---

## Payment Processing

### Stripe Payment Processing
**Service Category:** Payment Processing  
**Environment:** Production  
**Access Level:** PRODUCTION  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**Publishable Key:**
```
pk_live_51R9RpGAuYycpID5hykEKz1PLYpMC5f2xVcejaqipi31fCuAH4Yuwkxaz8oaTW1gxaZKFueKPfxBnj8zmsdhWICM7006c7mCTz2
```

**Purpose:** Production payment processing  
**Usage Context:** Client-side payment forms - safe for public use  
**Security Notes:** Live key - monitor transactions regularly  
**Webhook Secret:** [Required for payment verification - obtain from Stripe dashboard]

---

## Web Services & APIs

### Google Cloud Platform
**Service Category:** Cloud Services/APIs  
**Environment:** Production  
**Access Level:** ADMIN  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
AIzaSyD0zAxSq03Pos8gaLcB160hBf2yueph80M
```

**Purpose:** Google Cloud services and APIs  
**Usage Context:** General Google Cloud service access  
**Security Notes:** Restrict to specific services and IPs when possible

---

### Google Places API - Ekaty.com
**Service Category:** Location Services/Maps  
**Environment:** Production  
**Access Level:** READ-ONLY  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
AIzaSyA7Ic5d7Uzr8XgYBPWtMB4Z8UDFnjpWypo
```

**Purpose:** Location services specifically for Ekaty.com  
**Usage Context:** Frontend location features  
**Restrictions:** Limited to Ekaty.com domain  
**Security Notes:** Domain-restricted key

---

### Google Places API - Benchonly.com
**Service Category:** Location Services/Maps  
**Environment:** Production  
**Access Level:** READ-ONLY  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
AIzaSyDG8sJt_j2zN_lI_Ak7cYJ9Qi-2OxJbEiU
```

**Purpose:** Location services specifically for Benchonly.com  
**Usage Context:** Frontend location features  
**Restrictions:** Limited to Benchonly.com domain  
**Security Notes:** Domain-restricted key

---

## Domain & DNS Management

### GoDaddy Domain Management
**Service Category:** Domain Registration/DNS  
**Environment:** Production  
**Access Level:** ADMIN  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
9EE9DPNXA1p_TGcTTgAdCmgsrD1BdFZLh6
```

**API Secret:**
```
KbUA4FF1aCDgQBV8EqgLaE
```

**Purpose:** Domain registration and DNS management  
**Usage Context:** Only for GoDaddy-registered domains  
**Security Notes:** Full domain control - verify registrar before use

---

## Communication Services

### Resend Email Service
**Service Category:** Email/Communication  
**Environment:** Production  
**Access Level:** PRODUCTION  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
re_37YYP2iE_KbLqkdskcjngf9XqFMJZv1xG
```

**Purpose:** Transactional email sending  
**Usage Context:** System notifications and user communications  
**Security Notes:** Monitor sending volume and reputation

---

## Version Control

### GitHub Personal Access Token
**Service Category:** Version Control/CI/CD  
**Environment:** Production  
**Access Level:** ADMIN  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**Personal Access Token (Classic):**
```
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
```

**Purpose:** Repository access and CI/CD operations  
**Scope:** Full repository access  
**Security Notes:** Classic token - consider migrating to fine-grained tokens

---

## Third-Party APIs

### Spotify API
**Service Category:** Music/Entertainment  
**Environment:** Production  
**Access Level:** READ-ONLY  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**Client ID:**
```
e85c1a2c70e445cc998f53a7dc29a90a
```

**Client Secret:**
```
6193f5ff923442db851930e5a1b4758a
```

**Purpose:** Music integration features  
**Usage Context:** User music preferences and playback  
**Security Notes:** OAuth2 credentials - handle refresh tokens securely

---

## Backup & Recovery

### Backup Procedures
1. **Automated Backups:** Daily encrypted backups created with timestamp
2. **Backup Location:** Local secure storage with encryption
3. **Recovery Testing:** Monthly recovery tests to verify integrity
4. **Access Control:** Backup files encrypted with master password

### Emergency Contacts
- **Primary:** James Strickland (Owner)
- **Secondary:** System Administrator
- **Escalation:** Security Team

### Recovery Steps
1. Locate most recent backup file
2. Verify backup integrity
3. Decrypt using master password
4. Restore credentials to secure location
5. Test credential functionality
6. Update rotation schedules if needed

---

## Rotation Schedule

### High Priority (Monthly)
- Payment processing credentials
- Database administrative access
- Cloud infrastructure admin keys

### Medium Priority (Quarterly)
- AI service API keys
- Communication service keys
- Domain management credentials

### Low Priority (Annually)
- Read-only API keys
- Development environment credentials
- Third-party service integrations

### Rotation Checklist
- [ ] Generate new credentials
- [ ] Update all applications
- [ ] Test functionality
- [ ] Revoke old credentials
- [ ] Update documentation
- [ ] Notify team members

---

## Usage Guidelines for LLM Integration

### Best Practices:
1. **Always reference by service name** (e.g., "Use the OpenAI API key")
2. **Check environment context** before using credentials
3. **Verify access levels** match requirements
4. **Monitor usage patterns** for anomalies
5. **Follow principle of least privilege**

### Security Reminders:
- Never log credentials in plain text
- Use environment variables in production
- Implement credential rotation automation
- Monitor for unauthorized access
- Encrypt credentials at rest and in transit

---

**END OF DOCUMENT**

*This document contains sensitive security information. Handle with appropriate security measures.*