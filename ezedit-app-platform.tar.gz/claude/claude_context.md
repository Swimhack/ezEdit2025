se context7 mcp for all queries
utilize usage monitor to throttle fallback to another free llm to serve as backup during session limits  
 always validate work, especially UI and image work with Playwright MCP, only once the work is validated to be successfully completed, then you may continue, always opt to deploy to digital ocean with mcp, (crendentials:
digital ocean server

### Digital Ocean Cloud Infrastructure
**Service Category:** Cloud Computing/VPS  
**Environment:** Production  
**Access Level:** ADMIN  
**Created:** 2024-01-01  
**Last Rotated:** 2024-01-01  
**Next Rotation:** 2025-01-01  

**API Key:**
```
dop_v1_f5fb7c9657fa9470aec45e4f40907bf5fa41bdba0eab928704be54d2368995c4
```

**Account Password:**
```
MattKaylaS2two
```

**Purpose:** Hosting droplets, databases, and deployment infrastructure  
**Access Scope:** Full account access  
**Security Notes:** API key has full account privileges - monitor usage regularly

)
# CLAUDE.md - James Strickland's AI Context

# Run Claude with permission bypass (for file access issues)
claude --dangerously-skip-permissions

# or (same thing, clearer flag name)
claude --permission-mode bypassPermissions

# Claude AI Assistant Context

## Project Context for AI Assistance

### Working with EzEdit.co
This is a web-based FTP code editor project with AI assistance integration. When working on this project, keep in mind:

### Key Principles
1. **Security First**: All FTP credentials must be encrypted, all inputs validated
2. **Performance Focused**: Optimize for fast file operations and responsive UI
3. **User Experience**: Prioritize intuitive interface and smooth workflow
4. **Scalability**: Design for multiple concurrent users and large files

### Technology Stack Understanding
- **PHP Backend**: Handle FTP operations, authentication, and server-side logic
- **Vanilla JavaScript**: Keep frontend lightweight without framework dependencies
- **Monaco Editor**: Provide professional code editing experience
- **Supabase**: Manage user authentication and data storage
- **Claude API**: Power the AI assistant features

### Common Tasks
1. **FTP Operations**: Connection management, file CRUD, directory navigation
2. **Code Editing**: Monaco integration, syntax highlighting, file handling
3. **User Management**: Authentication flows, session handling, profile management
4. **AI Integration**: Code explanation, generation, debugging assistance
5. **Security**: Input validation, credential encryption, access control

### Code Quality Standards
- Follow PSR-12 coding standards for PHP
- Use modern JavaScript (ES6+) features
- Implement comprehensive error handling
- Write secure, validated code
- Optimize for performance

### File Organization
- Keep public files in `/public/` directory
- Store configuration in `/config/`
- Use modular JavaScript architecture
- Separate concerns (auth, FTP, editor, AI)

### Development Workflow
1. Understand requirements clearly
2. Design secure, scalable solutions
3. Implement with proper error handling
4. Test thoroughly before deployment
5. Document code and architecture decisions

### Security Considerations
- Never store plain text passwords
- Validate all user inputs
- Use prepared statements for database queries
- Implement proper session management
- Add rate limiting for API endpoints

### Performance Optimization
- Use lazy loading for large file lists
- Implement file caching where appropriate
- Minimize network requests
- Optimize JavaScript bundle size
- Use efficient database queries

### AI Assistant Guidelines
When implementing AI features:
- Track token usage for billing
- Implement proper context management
- Handle API failures gracefully
- Provide clear user feedback
- Maintain conversation history

### User Experience Focus
- Three-pane layout (explorer, editor, assistant)
- Responsive design for different screen sizes
- Keyboard shortcuts for power users
- Clear error messages and loading states
- Intuitive navigation and file management

### Business Considerations
- Design for freemium model with usage limits
- Track metrics for business intelligence
- Ensure scalability for growth
- Plan for team collaboration features
- Consider enterprise requirements

## Communication Style
- Be direct and solution-focused
- Provide code examples when helpful
- Explain security implications
- Consider performance impact
- Suggest best practices

## Problem-Solving Approach
1. Analyze requirements and constraints
2. Consider security and performance impact
3. Design modular, maintainable solutions
4. Implement with proper error handling
5. Test and validate functionality
6. Document decisions and trade-offs