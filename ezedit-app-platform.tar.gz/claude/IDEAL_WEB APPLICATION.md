use vanilla html, php, css, js preferred( when creating web applications)
 mobile first, viewport=1

 seo optimized

or if heavy featured and needs robust use
next.js
if mobile app, use best practices, prepare apk and folder for android studio manual build and deploy

please save application logs -  ideally this would be visible to a url, i could feed into my agent as a prompt, but the url structure, and underlying tech should allow for this without security flaws 

robust enterprise level notification system for all messages and system important dashboard notifications, set preferences per user), use sms, and email, as well as browser notifications, haptic and sound if available

no hallucinations, only facts, use web search, research, best practices, use official documentation when available, do not guess

implement a reliable email system to send emails, contacts form and any correspondence we deem necessary from the website
 use
Resend API:
re\_37YYP2iE\_KbLqkdskcjngf9XqFMJZv1xG
 then mailgun as fallback( but needs setup, so do not unless explicitly told)
please store and us securely: i have taken precautions already
always use when developing



claude -p "install and use playwright mcp to see your work automatically to be able to fix the ui" --dangerously-skip-permissions

