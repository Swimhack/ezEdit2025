# Deployment Strategy Agent

## Role: Deployment Operations Manager

**Primary Responsibility:** Maintain deployment procedures, environment configurations, and ensure reliable production deployments for EzEdit.co.

## Current Deployment Status

### Environment Overview
- **Production:** DigitalOcean Droplet (159.65.224.175) - ezedit-mvp
- **Staging:** Local development environment
- **Development:** Local XAMPP/WAMP setup

### Deployment Architecture

#### Current Setup (Hybrid)
- **Static Assets:** Netlify CDN (planned)
- **PHP Backend:** DigitalOcean Droplet
- **Database:** Supabase (external SaaS)
- **AI Services:** Claude API (external)

#### Target Architecture (Production)
- **Frontend:** Netlify or DigitalOcean App Platform
- **Backend:** DigitalOcean Droplet or App Platform
- **Database:** Supabase PostgreSQL
- **CDN:** DigitalOcean Spaces or Netlify
- **Monitoring:** DigitalOcean Monitoring + Custom dashboards

## Deployment Environments

### Production Environment
**Server:** DigitalOcean Droplet (ezedit-mvp)  
**IP:** 159.65.224.175  
**OS:** Ubuntu 22.04 LTS  
**Web Server:** Apache2 or Nginx  
**PHP:** 8.2+  
**SSL:** Let's Encrypt certificate  

**Configuration Requirements:**
- PHP Extensions: `ftp`, `session`, `json`, `curl`, `openssl`
- Memory Limit: 256MB minimum
- Upload Limit: 50MB for file operations
- Execution Time: 300 seconds for large file operations

### Staging Environment
**Purpose:** Pre-production testing and validation  
**Setup:** Mirror of production environment  
**Access:** Internal team only  
**Data:** Sanitized production data or test data  

### Development Environment
**Setup:** Local XAMPP/WAMP or Docker  
**Requirements:** PHP 8.2+, all necessary extensions  
**Database:** Local PostgreSQL or SQLite for testing  
**Services:** Mock AI responses for development  

## Deployment Procedures

### Current Deployment Process

#### Manual Deployment (Current)
1. **Code Review:** Ensure all changes are reviewed and approved
2. **Testing:** Run manual test checklist
3. **Package Creation:** Create deployment archive
4. **Server Access:** Use DigitalOcean web console or SSH
5. **File Upload:** Upload and extract files to `/var/www/html/`
6. **Permission Setting:** Set appropriate file permissions
7. **Service Restart:** Restart web server if needed
8. **Verification:** Test critical paths on production

#### Target Automated Deployment (Future)
1. **Git Push:** Developer pushes to main branch
2. **CI Pipeline:** Automated testing and validation
3. **Build Process:** Create optimized deployment package
4. **Staging Deploy:** Automatic deployment to staging
5. **Staging Tests:** Automated E2E tests on staging
6. **Production Deploy:** Automatic or one-click production deployment
7. **Health Checks:** Automated post-deployment verification
8. **Rollback:** Automatic rollback if health checks fail

### Deployment Checklist

#### Pre-Deployment
- [ ] All code changes reviewed and approved
- [ ] All tests passing (unit, integration, manual)
- [ ] Database migrations prepared (if applicable)
- [ ] Environment variables updated
- [ ] Third-party service status verified (Supabase, Claude API)
- [ ] Backup of current production taken
- [ ] Deployment window scheduled (low traffic time)

#### During Deployment
- [ ] Create deployment package with correct file structure
- [ ] Upload files to server (web console, FTP, or rsync)
- [ ] Extract files to correct directory (`/var/www/html/`)
- [ ] Set file permissions (`chown www-data:www-data`, `chmod 755/644`)
- [ ] Update configuration files if needed
- [ ] Clear any caches (PHP opcache, application cache)
- [ ] Restart services (Apache/Nginx, PHP-FPM)

#### Post-Deployment
- [ ] Verify homepage loads correctly
- [ ] Test authentication flow (login/logout)
- [ ] Verify dashboard functionality
- [ ] Test editor interface loads
- [ ] Check FTP connection capability
- [ ] Test AI assistant interface
- [ ] Monitor error logs for new issues
- [ ] Update team on deployment status

### Rollback Procedures

#### Quick Rollback (< 5 minutes)
1. **Identify Issue:** Determine if rollback is necessary
2. **Access Server:** Connect via web console or SSH
3. **Restore Backup:** Replace current files with previous version
4. **Restart Services:** Restart web server
5. **Verify Functionality:** Test critical user paths
6. **Communicate Status:** Update team and users if necessary

#### Full Rollback (< 15 minutes)
1. **Database Rollback:** Restore database if schema changes were made
2. **Configuration Rollback:** Restore previous configuration files
3. **Cache Clear:** Clear all caches and restart services
4. **External Services:** Revert any third-party service changes
5. **Full Testing:** Complete smoke test of all functionality
6. **Incident Report:** Document what went wrong and why

## Configuration Management

### Environment Variables

#### Production Configuration
```bash
# Database
SUPABASE_URL=https://natjhcqynqziccsnwim.supabase.co
SUPABASE_ANON_KEY=[production_key]

# AI Services
CLAUDE_API_KEY=[production_key]
OPENAI_API_KEY=[fallback_key]

# Security
ENCRYPTION_KEY=[256_bit_key]
SESSION_SECRET=[random_string]

# Application
APP_ENV=production
APP_DEBUG=false
APP_URL=https://ezedit.co
```

#### Development Configuration
```bash
# Database
SUPABASE_URL=https://natjhcqynqziccsnwim.supabase.co
SUPABASE_ANON_KEY=[development_key]

# AI Services (Mock or low-rate-limit keys)
CLAUDE_API_KEY=[development_key]
OPENAI_API_KEY=[development_key]

# Security (Non-production keys)
ENCRYPTION_KEY=[development_key]
SESSION_SECRET=[development_secret]

# Application
APP_ENV=development
APP_DEBUG=true
APP_URL=http://localhost
```

### File Structure Requirements

#### Production Directory Structure
```
/var/www/html/
├── index.php                 # Homepage
├── dashboard.php             # User dashboard
├── editor.php               # Main editor interface
├── auth/
│   ├── login.php            # Authentication
│   ├── logout.php           # Session cleanup
│   └── register.php         # User registration
├── css/
│   ├── main.css             # Global styles
│   ├── dashboard.css        # Dashboard styles
│   ├── editor.css          # Editor styles
│   └── auth.css            # Authentication styles
├── js/
│   ├── main.js             # Global JavaScript
│   ├── dashboard.js        # Dashboard functionality
│   ├── editor.js           # Editor functionality
│   ├── auth.js             # Authentication handling
│   ├── ftp-client.js       # FTP operations
│   └── ai-assistant.js     # AI integration
├── ftp/
│   └── ftp-handler.php     # FTP backend operations
└── config/
    └── config.php          # Application configuration
```

### Server Configuration

#### Apache Configuration (`.htaccess`)
```apache
RewriteEngine On

# Force HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Security headers
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"
Header always set Strict-Transport-Security "max-age=63072000; includeSubDomains; preload"

# PHP settings
php_value upload_max_filesize 50M
php_value post_max_size 50M
php_value max_execution_time 300
php_value memory_limit 256M
```

#### Nginx Configuration (if used)
```nginx
server {
    listen 80;
    server_name ezedit.co www.ezedit.co;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ezedit.co www.ezedit.co;
    
    root /var/www/html;
    index index.php index.html;
    
    # SSL configuration
    ssl_certificate /etc/letsencrypt/live/ezedit.co/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/ezedit.co/privkey.pem;
    
    # Security headers
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload";
    
    # PHP handling
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
    
    # Static assets caching
    location ~* \.(css|js|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

## Monitoring and Health Checks

### Health Check Endpoints
- **Basic Health:** `/health.php` - Returns 200 if server is responding
- **Database Health:** `/health-db.php` - Checks Supabase connection
- **FTP Health:** `/health-ftp.php` - Tests FTP functionality
- **AI Health:** `/health-ai.php` - Verifies AI API connectivity

### Monitoring Metrics
- **Server Response Time:** < 500ms for static pages
- **Database Query Time:** < 200ms for typical queries
- **FTP Operation Time:** < 2 seconds for file operations
- **AI Response Time:** < 10 seconds for assistant queries
- **Error Rate:** < 1% of all requests
- **Uptime:** > 99.9% monthly availability

### Alerting Rules
- **Critical:** Server down, database unreachable, SSL certificate expiring
- **Warning:** High response times, elevated error rates, disk space low
- **Info:** Deployment completed, backup finished, certificate renewed

## Security Considerations

### Deployment Security
- **Access Control:** Limited SSH access, strong passwords/keys
- **File Permissions:** Proper ownership and permissions for web files
- **Database Security:** Encrypted connections, limited user privileges
- **API Keys:** Secure storage, rotation schedule
- **SSL/TLS:** Valid certificates, secure protocols only

### Production Hardening
- **Server Updates:** Regular security updates and patches
- **Firewall Rules:** Only necessary ports open (80, 443, 22)
- **Intrusion Detection:** Monitor for suspicious activity
- **Backup Security:** Encrypted backups, secure storage
- **Audit Logging:** Track access and changes

## Disaster Recovery

### Backup Strategy
- **Daily Backups:** Automated full server backup
- **Database Backups:** Hourly Supabase backups (automatic)
- **Code Backups:** Git repository (multiple remotes)
- **Configuration Backups:** Weekly configuration snapshots

### Recovery Procedures
1. **Assess Damage:** Determine extent of issue
2. **Isolate Problem:** Prevent further damage
3. **Restore from Backup:** Use most recent clean backup
4. **Test Functionality:** Verify all systems working
5. **Document Incident:** Record what happened and how it was fixed

### Recovery Time Objectives
- **Critical Systems:** < 1 hour recovery time
- **Non-Critical Systems:** < 4 hours recovery time
- **Data Loss:** < 1 hour of data loss acceptable

---

**Last Updated:** 2025-01-23  
**Version:** 1.0  
**Next Review:** 2025-01-30  
**Owner:** Deployment Strategy Agent