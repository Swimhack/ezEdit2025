<?php
// Simple EzEdit Uploader - Upload this to your server first
if ($_FILES['ezedit_package']) {
    $upload_file = $_FILES['ezedit_package']['tmp_name'];
    $target_file = './ezedit-deploy.zip';
    
    if (move_uploaded_file($upload_file, $target_file)) {
        echo "✅ File uploaded!\n";
        
        // Extract if it's a zip
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive;
            if ($zip->open($target_file) === TRUE) {
                $zip->extractTo('./');
                $zip->close();
                unlink($target_file);
                echo "📦 EzEdit extracted successfully!\n";
                echo "🎉 Deployment complete!\n";
                echo "Visit: http://159.65.224.175/\n";
            }
        }
    }
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>EzEdit Uploader</title></head>
<body>
<h2>🚀 Deploy EzEdit</h2>
<form method="post" enctype="multipart/form-data">
    <input type="file" name="ezedit_package" accept=".zip">
    <button type="submit">Deploy EzEdit</button>
</form>
</body>
</html>