<?php
// Simple file uploader for EzEdit deployment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['deployment'])) {
    $uploadDir = './';
    $uploadFile = $uploadDir . basename($_FILES['deployment']['name']);
    
    if (move_uploaded_file($_FILES['deployment']['tmp_name'], $uploadFile)) {
        echo "✅ File uploaded successfully: " . htmlspecialchars(basename($_FILES['deployment']['name']));
        
        // If it's a ZIP file, extract it
        if (pathinfo($uploadFile, PATHINFO_EXTENSION) === 'zip') {
            $zip = new ZipArchive;
            if ($zip->open($uploadFile) === TRUE) {
                $zip->extractTo('./');
                $zip->close();
                echo "<br>📦 Archive extracted successfully";
                unlink($uploadFile); // Remove ZIP after extraction
            }
        }
    } else {
        echo "❌ Upload failed";
    }
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>EzEdit Deployment Uploader</title></head>
<body>
<h2>🚀 Deploy EzEdit</h2>
<form enctype="multipart/form-data" method="post">
    <input type="file" name="deployment" accept=".zip,.tar.gz" required>
    <button type="submit">Deploy EzEdit</button>
</form>
</body>
</html>