This agent executes NLP-translated system commands through the terminal.
