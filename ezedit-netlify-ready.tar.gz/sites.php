<?php
/**
 * EzEdit.co - My Sites Page
 * Redirects to dashboard.php since sites are managed there
 */

header('Location: dashboard.php');
exit;