<?php
/**
 * EzEdit.co AI Assistant API
 * Claude Code Integration for Code Analysis and Assistance
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Get request data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit();
}

// Validate required fields
$message = $data['message'] ?? '';
$code = $data['code'] ?? '';
$language = $data['language'] ?? 'plaintext';
$filename = $data['filename'] ?? '';

if (empty($message)) {
    http_response_code(400);
    echo json_encode(['error' => 'Message is required']);
    exit();
}

try {
    $response = processAIRequest($message, $code, $language, $filename);
    echo json_encode($response);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error: ' . $e->getMessage()]);
}

function processAIRequest($message, $code, $language, $filename) {
    // Simulate Claude Code analysis
    $response = analyzeWithClaudeCode($message, $code, $language, $filename);
    
    return [
        'success' => true,
        'response' => $response,
        'timestamp' => date('c'),
        'model' => 'claude-code'
    ];
}

function analyzeWithClaudeCode($message, $code, $language, $filename) {
    // Mock Claude Code responses based on request type
    $lowerMessage = strtolower($message);
    
    // Code explanation requests
    if (strpos($lowerMessage, 'explain') !== false || strpos($lowerMessage, 'what does') !== false) {
        return generateCodeExplanation($code, $language, $filename);
    }
    
    // Bug finding requests
    if (strpos($lowerMessage, 'bug') !== false || strpos($lowerMessage, 'error') !== false || strpos($lowerMessage, 'issue') !== false) {
        return generateBugAnalysis($code, $language);
    }
    
    // Optimization requests
    if (strpos($lowerMessage, 'optimize') !== false || strpos($lowerMessage, 'improve') !== false || strpos($lowerMessage, 'performance') !== false) {
        return generateOptimizationSuggestions($code, $language);
    }
    
    // Code generation requests
    if (strpos($lowerMessage, 'generate') !== false || strpos($lowerMessage, 'create') !== false || strpos($lowerMessage, 'write') !== false) {
        return generateCodeSuggestion($message, $language);
    }
    
    // Documentation requests
    if (strpos($lowerMessage, 'document') !== false || strpos($lowerMessage, 'comment') !== false) {
        return generateDocumentation($code, $language);
    }
    
    // Security analysis
    if (strpos($lowerMessage, 'security') !== false || strpos($lowerMessage, 'vulnerable') !== false || strpos($lowerMessage, 'secure') !== false) {
        return generateSecurityAnalysis($code, $language);
    }
    
    // General conversation
    return generateGeneralResponse($message, $code, $language, $filename);
}

function generateCodeExplanation($code, $language, $filename) {
    if (empty($code)) {
        return "I'd be happy to explain code for you! Please select some code in the editor and ask again, or paste the code you'd like me to explain.";
    }
    
    $explanations = [
        'javascript' => "This JavaScript code appears to handle DOM manipulation and event handling. Key features include:\n\n• Event listeners for user interactions\n• Functions for updating the UI dynamically\n• Modern ES6+ syntax with arrow functions\n• Proper error handling patterns\n\nThe code follows good practices for web development and maintains clean separation of concerns.",
        
        'php' => "This PHP code implements server-side logic with the following characteristics:\n\n• Session management for user authentication\n• Database interactions with proper sanitization\n• HTML generation with security considerations\n• Error handling and validation\n\nThe code follows PHP best practices and includes security measures against common vulnerabilities.",
        
        'html' => "This HTML structure defines the page layout and content:\n\n• Semantic HTML5 elements for better accessibility\n• Proper meta tags for SEO and mobile responsiveness\n• Organized heading hierarchy\n• Form elements with appropriate input types\n\nThe markup follows web standards and accessibility guidelines.",
        
        'css' => "This CSS defines the visual styling and layout:\n\n• Responsive design patterns for mobile compatibility\n• Flexbox/Grid layouts for modern positioning\n• CSS custom properties for maintainable theming\n• Hover effects and transitions for better UX\n\nThe styles are well-organized and follow modern CSS practices."
    ];
    
    return $explanations[$language] ?? "This code defines the structure and logic for your application. It includes variable declarations, function definitions, and control flow statements that work together to implement the desired functionality.";
}

function generateBugAnalysis($code, $language) {
    if (empty($code)) {
        return "I can help you find and fix bugs! Please select the problematic code in the editor so I can analyze it for potential issues.";
    }
    
    $bugAnalyses = [
        'javascript' => "🔍 **Code Analysis Complete**\n\nPotential issues found:\n\n• **Variable Scope**: Check for `var` declarations that should be `let` or `const`\n• **Event Listeners**: Ensure proper cleanup to prevent memory leaks\n• **Async Handling**: Verify all promises have proper error handling\n• **DOM Access**: Add null checks before accessing DOM elements\n\n💡 **Recommendations:**\n- Use strict mode (`'use strict';`)\n- Add try-catch blocks around risky operations\n- Validate user input before processing",
        
        'php' => "🔍 **Security & Logic Analysis**\n\nPotential vulnerabilities found:\n\n• **SQL Injection**: Ensure all database queries use prepared statements\n• **XSS Prevention**: Use `htmlspecialchars()` for all user output\n• **CSRF Protection**: Add CSRF tokens to forms\n• **Input Validation**: Sanitize and validate all user inputs\n\n💡 **Security Recommendations:**\n- Enable PHP error reporting in development only\n- Use password hashing with `password_hash()`\n- Implement proper session management",
        
        'css' => "🔍 **CSS Analysis Complete**\n\nPotential issues found:\n\n• **Specificity Conflicts**: Some selectors may override others unexpectedly\n• **Browser Compatibility**: Consider vendor prefixes for newer properties\n• **Performance**: Large CSS files may impact loading times\n• **Responsive Design**: Check media query breakpoints\n\n💡 **Optimization Tips:**\n- Minimize and compress CSS for production\n- Use CSS custom properties for consistent theming\n- Consider critical CSS loading strategies"
    ];
    
    return $bugAnalyses[$language] ?? "I've analyzed your code for potential issues. Common problems to check for include syntax errors, logic flaws, security vulnerabilities, and performance bottlenecks. Consider adding error handling and input validation where appropriate.";
}

function generateOptimizationSuggestions($code, $language) {
    $optimizations = [
        'javascript' => "⚡ **Performance Optimization Suggestions**\n\n• **Debounce Events**: Add debouncing to scroll/resize listeners\n• **Lazy Loading**: Implement lazy loading for images and content\n• **Bundle Optimization**: Minimize and compress JavaScript files\n• **DOM Manipulation**: Cache DOM queries and batch updates\n\n🚀 **Code Improvements:**\n- Use `requestAnimationFrame` for smooth animations\n- Implement virtual scrolling for large lists\n- Consider Web Workers for heavy computations",
        
        'php' => "⚡ **PHP Performance Optimization**\n\n• **Caching**: Implement OpCode caching (OPcache)\n• **Database**: Add proper indexing and query optimization\n• **Memory**: Use generators for large datasets\n• **Sessions**: Consider database or Redis session storage\n\n🚀 **Best Practices:**\n- Enable gzip compression\n- Use autoloading for classes\n- Implement database connection pooling",
        
        'css' => "⚡ **CSS Performance Optimization**\n\n• **File Size**: Minimize and compress CSS\n• **Critical Path**: Inline critical CSS for above-fold content\n• **Animations**: Use `transform` and `opacity` for smooth animations\n• **Selectors**: Avoid overly complex selector chains\n\n🚀 **Modern Techniques:**\n- Use CSS Grid for complex layouts\n- Implement CSS custom properties\n- Consider CSS-in-JS for dynamic styling"
    ];
    
    return $optimizations[$language] ?? "Here are some general optimization strategies: minimize file sizes, reduce HTTP requests, optimize images, implement caching, and use efficient algorithms. Consider profiling your application to identify specific bottlenecks.";
}

function generateCodeSuggestion($message, $language) {
    // Extract what the user wants to create
    $suggestions = [
        'function' => [
            'javascript' => "```javascript\n// Example function based on your request\nfunction handleUserAction(data) {\n    try {\n        // Validate input\n        if (!data || typeof data !== 'object') {\n            throw new Error('Invalid data provided');\n        }\n        \n        // Process the data\n        const result = processData(data);\n        \n        // Return success response\n        return {\n            success: true,\n            result: result,\n            timestamp: new Date().toISOString()\n        };\n    } catch (error) {\n        console.error('Error in handleUserAction:', error);\n        return {\n            success: false,\n            error: error.message\n        };\n    }\n}\n```",
            
            'php' => "```php\n<?php\n// Example function based on your request\nfunction handleUserData($data) {\n    try {\n        // Validate input\n        if (empty($data) || !is_array($data)) {\n            throw new InvalidArgumentException('Invalid data provided');\n        }\n        \n        // Sanitize data\n        $cleanData = array_map('htmlspecialchars', $data);\n        \n        // Process the data\n        $result = processData($cleanData);\n        \n        return [\n            'success' => true,\n            'result' => $result,\n            'timestamp' => date('c')\n        ];\n    } catch (Exception $e) {\n        error_log('Error in handleUserData: ' . $e->getMessage());\n        return [\n            'success' => false,\n            'error' => $e->getMessage()\n        ];\n    }\n}\n?>\n```"
        ],
        
        'component' => [
            'html' => "```html\n<!-- Example component based on your request -->\n<div class=\"user-card\">\n    <div class=\"user-avatar\">\n        <img src=\"avatar.jpg\" alt=\"User Avatar\">\n    </div>\n    <div class=\"user-info\">\n        <h3 class=\"user-name\">John Doe</h3>\n        <p class=\"user-email\">john@example.com</p>\n        <div class=\"user-actions\">\n            <button class=\"btn btn-primary\">Edit</button>\n            <button class=\"btn btn-secondary\">Delete</button>\n        </div>\n    </div>\n</div>\n```",
            
            'css' => "```css\n/* Example component styles */\n.user-card {\n    display: flex;\n    align-items: center;\n    padding: 1rem;\n    background: white;\n    border-radius: 8px;\n    box-shadow: 0 2px 4px rgba(0,0,0,0.1);\n    margin-bottom: 1rem;\n}\n\n.user-avatar {\n    margin-right: 1rem;\n}\n\n.user-avatar img {\n    width: 60px;\n    height: 60px;\n    border-radius: 50%;\n    object-fit: cover;\n}\n\n.user-info {\n    flex: 1;\n}\n\n.user-name {\n    margin: 0 0 0.5rem 0;\n    font-size: 1.1rem;\n    font-weight: 600;\n}\n\n.user-email {\n    margin: 0 0 1rem 0;\n    color: #666;\n    font-size: 0.9rem;\n}\n\n.user-actions {\n    display: flex;\n    gap: 0.5rem;\n}\n```"
        ]
    ];
    
    // Simple keyword matching to determine what to generate
    if (strpos($message, 'function') !== false) {
        return $suggestions['function'][$language] ?? "I can help you create a function! What specific functionality do you need it to implement?";
    }
    
    if (strpos($message, 'component') !== false || strpos($message, 'card') !== false) {
        return $suggestions['component'][$language] ?? "I can help you create a component! What type of component do you need?";
    }
    
    return "I'd be happy to generate code for you! Could you be more specific about what you'd like me to create? For example:\n\n• A function to handle specific logic\n• A component for the UI\n• A form with validation\n• An API endpoint\n• Database queries\n\nJust let me know what you need!";
}

function generateDocumentation($code, $language) {
    if (empty($code)) {
        return "I can help you add documentation to your code! Please select the code you'd like me to document and I'll generate appropriate comments and documentation.";
    }
    
    $docStyles = [
        'javascript' => "Here's how to document your JavaScript code:\n\n```javascript\n/**\n * Handles user authentication and session management\n * @param {Object} credentials - User login credentials\n * @param {string} credentials.email - User email address\n * @param {string} credentials.password - User password\n * @returns {Promise<Object>} Authentication result\n * @throws {Error} When credentials are invalid\n */\nfunction authenticateUser(credentials) {\n    // Implementation here\n}\n```\n\n💡 **Documentation Tips:**\n- Use JSDoc format for function documentation\n- Include parameter types and descriptions\n- Document return values and exceptions\n- Add inline comments for complex logic",
        
        'php' => "Here's how to document your PHP code:\n\n```php\n<?php\n/**\n * Handles user authentication and session management\n * \n * This function validates user credentials against the database\n * and creates a session if authentication is successful.\n * \n * @param array $credentials User login credentials\n * @param string $credentials['email'] User email address\n * @param string $credentials['password'] User password\n * @return array Authentication result with status and user data\n * @throws InvalidArgumentException When credentials are missing\n * @throws AuthenticationException When credentials are invalid\n */\nfunction authenticateUser(array $credentials): array {\n    // Implementation here\n}\n?>\n```\n\n💡 **Documentation Best Practices:**\n- Use PHPDoc format for all functions and classes\n- Document all parameters and return types\n- Include usage examples for complex functions",
        
        'css' => "Here's how to document your CSS code:\n\n```css\n/**\n * User Card Component\n * \n * A reusable card component for displaying user information\n * with avatar, name, email, and action buttons.\n * \n * Usage: Apply .user-card class to container element\n * \n * @since 1.0.0\n * @author Your Name\n */\n.user-card {\n    /* Base card styling */\n    display: flex;\n    align-items: center;\n    padding: 1rem;\n    \n    /* Visual appearance */\n    background: white;\n    border-radius: 8px;\n    box-shadow: 0 2px 4px rgba(0,0,0,0.1);\n}\n\n/* Avatar section - displays user profile image */\n.user-card .avatar {\n    margin-right: 1rem;\n}\n```\n\n💡 **CSS Documentation Tips:**\n- Document component purpose and usage\n- Explain complex selectors and calculations\n- Group related styles with comments"
    ];
    
    return $docStyles[$language] ?? "I can help you add proper documentation to your code. Good documentation should explain the purpose, parameters, return values, and usage examples for your functions and components.";
}

function generateSecurityAnalysis($code, $language) {
    $securityAdvice = [
        'php' => "🔒 **Security Analysis for PHP Code**\n\n**Critical Security Checks:**\n\n• **SQL Injection Prevention**\n  - Use prepared statements for all database queries\n  - Never concatenate user input directly into SQL\n\n• **Cross-Site Scripting (XSS)**\n  - Use `htmlspecialchars()` for all user output\n  - Validate and sanitize all input data\n\n• **Cross-Site Request Forgery (CSRF)**\n  - Implement CSRF tokens in all forms\n  - Verify tokens on form submission\n\n• **Authentication & Sessions**\n  - Use `password_hash()` and `password_verify()`\n  - Implement proper session regeneration\n  - Set secure session cookie flags\n\n• **File Upload Security**\n  - Validate file types and sizes\n  - Store uploads outside web root\n  - Check file content, not just extension\n\n**Recommended Security Headers:**\n```php\nheader('X-Content-Type-Options: nosniff');\nheader('X-Frame-Options: DENY');\nheader('X-XSS-Protection: 1; mode=block');\n```",
        
        'javascript' => "🔒 **Security Analysis for JavaScript Code**\n\n**Client-Side Security Considerations:**\n\n• **Input Validation**\n  - Validate all user input on both client and server\n  - Sanitize data before processing\n\n• **DOM Manipulation**\n  - Use `textContent` instead of `innerHTML` when possible\n  - Validate data before inserting into DOM\n\n• **API Security**\n  - Use HTTPS for all API communications\n  - Implement proper authentication tokens\n  - Don't store sensitive data in localStorage\n\n• **Content Security Policy**\n  - Implement CSP headers to prevent XSS\n  - Avoid inline scripts and styles\n\n• **Third-Party Dependencies**\n  - Regularly audit npm packages for vulnerabilities\n  - Use tools like `npm audit` for security checks\n\n**Secure Coding Example:**\n```javascript\n// Safe DOM manipulation\nconst userInput = sanitizeInput(input.value);\nelement.textContent = userInput; // Not innerHTML\n\n// Secure API calls\nfetch('/api/data', {\n    method: 'POST',\n    headers: {\n        'Content-Type': 'application/json',\n        'Authorization': `Bearer ${token}`\n    },\n    body: JSON.stringify(data)\n});\n```",
        
        'html' => "🔒 **Security Analysis for HTML Code**\n\n**HTML Security Best Practices:**\n\n• **Form Security**\n  - Always include CSRF tokens in forms\n  - Use proper input types for validation\n  - Set appropriate `autocomplete` attributes\n\n• **Content Security**\n  - Avoid inline JavaScript and CSS\n  - Use `rel=\"noopener\"` for external links\n  - Implement proper Content Security Policy\n\n• **Data Attributes**\n  - Don't store sensitive data in HTML attributes\n  - Validate all data before rendering\n\n**Secure Form Example:**\n```html\n<form method=\"POST\" action=\"/submit\">\n    <input type=\"hidden\" name=\"csrf_token\" value=\"{{ csrf_token }}\">\n    <input type=\"email\" name=\"email\" required autocomplete=\"email\">\n    <input type=\"password\" name=\"password\" required autocomplete=\"current-password\">\n    <button type=\"submit\">Submit</button>\n</form>\n```",
        
        'css' => "🔒 **Security Considerations for CSS**\n\n**CSS Security Best Practices:**\n\n• **Content Injection**\n  - Avoid using `content` property with user data\n  - Be careful with CSS `url()` functions\n\n• **Clickjacking Prevention**\n  - Use `pointer-events: none` carefully\n  - Implement proper z-index management\n\n• **Information Disclosure**\n  - Don't include sensitive data in CSS comments\n  - Minimize CSS to remove development comments\n\n• **Performance Security**\n  - Avoid CSS expressions (legacy IE)\n  - Limit complex selectors that could cause DoS\n\nCSS is generally safe, but be mindful of these considerations when building secure applications."
    ];
    
    return $securityAdvice[$language] ?? "Security is crucial for web applications. Key areas to focus on include input validation, output encoding, authentication, authorization, and protection against common vulnerabilities like XSS, CSRF, and SQL injection.";
}

function generateGeneralResponse($message, $code, $language, $filename) {
    $responses = [
        "I'm Claude Code, your AI coding assistant! I can help you with code analysis, debugging, optimization, and generation. What would you like to work on?",
        
        "As Claude Code, I'm here to assist with your development workflow. I can explain code, find bugs, suggest improvements, and help with best practices. How can I help?",
        
        "I'm ready to help with your coding tasks! Whether you need code explanation, debugging assistance, or optimization suggestions, just let me know what you're working on.",
        
        "Hello! I'm Claude Code, integrated directly into EzEdit.co. I can analyze your code, suggest improvements, help with debugging, and generate code snippets. What would you like to explore?",
        
        "I see you're working" . ($filename ? " on `{$filename}`" : " on some code") . ". I can help you understand it better, find potential issues, or suggest improvements. What specific assistance do you need?"
    ];
    
    return $responses[array_rand($responses)];
}
?>