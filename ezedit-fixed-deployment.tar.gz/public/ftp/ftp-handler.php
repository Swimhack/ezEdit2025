<?php
/**
 * EzEdit.co FTP Handler
 * Handles FTP operations for the web-based editor
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

// Get action from POST data
$action = $_POST['action'] ?? '';

if (empty($action)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Action is required']);
    exit();
}

try {
    $response = handleFTPAction($action, $_POST);
    echo json_encode($response);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error: ' . $e->getMessage()]);
}

function handleFTPAction($action, $data) {
    switch ($action) {
        case 'connect':
            return connectToFTP($data);
        case 'disconnect':
            return disconnectFromFTP();
        case 'list':
            return listFiles($data);
        case 'get':
            return getFile($data);
        case 'put':
            return putFile($data);
        case 'mkdir':
            return createDirectory($data);
        case 'delete':
            return deleteFile($data);
        case 'rename':
            return renameFile($data);
        case 'permissions':
            return getPermissions($data);
        case 'chmod':
            return setPermissions($data);
        case 'test':
            return testConnection($data);
        default:
            return ['success' => false, 'error' => 'Unknown action: ' . $action];
    }
}

function connectToFTP($data) {
    $host = $data['host'] ?? '';
    $port = intval($data['port'] ?? 21);
    $username = $data['username'] ?? '';
    $password = $data['password'] ?? '';
    $secure = isset($data['secure']) && $data['secure'];
    
    // Validate input
    if (empty($host) || empty($username) || empty($password)) {
        return ['success' => false, 'error' => 'Host, username, and password are required'];
    }
    
    // For demo purposes, simulate successful connection
    // In production, you would actually connect to FTP server
    if (simulateFTPConnection($host, $port, $username, $password, $secure)) {
        // Store connection info in session for subsequent requests
        session_start();
        $_SESSION['ftp_connection'] = [
            'host' => $host,
            'port' => $port,
            'username' => $username,
            'secure' => $secure,
            'connected_at' => time()
        ];
        
        return [
            'success' => true,
            'message' => 'Connected to FTP server successfully',
            'server_info' => [
                'host' => $host,
                'port' => $port,
                'secure' => $secure
            ]
        ];
    } else {
        return ['success' => false, 'error' => 'Failed to connect to FTP server'];
    }
}

function simulateFTPConnection($host, $port, $username, $password, $secure) {
    // Simulate connection validation
    // In real implementation, you would use ftp_connect() or ftp_ssl_connect()
    
    // Basic validation
    if (strlen($host) < 3 || strlen($username) < 1 || strlen($password) < 1) {
        return false;
    }
    
    // Simulate some common failure cases
    if ($host === 'invalid.host' || $username === 'baduser' || $password === 'wrongpass') {
        return false;
    }
    
    // Simulate network timeout for certain hosts
    if (strpos($host, 'timeout') !== false) {
        usleep(500000); // 0.5 second delay
        return false;
    }
    
    // For demo, assume most connections succeed
    return true;
}

function disconnectFromFTP() {
    session_start();
    if (isset($_SESSION['ftp_connection'])) {
        unset($_SESSION['ftp_connection']);
    }
    
    return ['success' => true, 'message' => 'Disconnected from FTP server'];
}

function listFiles($data) {
    session_start();
    if (!isset($_SESSION['ftp_connection'])) {
        return ['success' => false, 'error' => 'Not connected to FTP server'];
    }
    
    $directory = $data['directory'] ?? '/';
    
    // Simulate file listing
    $files = generateMockFileList($directory);
    
    return [
        'success' => true,
        'files' => $files,
        'directory' => $directory
    ];
}

function generateMockFileList($directory) {
    // Generate mock file structure based on directory
    $baseFiles = [
        [
            'name' => 'index.php',
            'type' => 'file',
            'size' => 2048,
            'modified' => time() - 86400,
            'permissions' => '644'
        ],
        [
            'name' => 'style.css',
            'type' => 'file',
            'size' => 1024,
            'modified' => time() - 3600,
            'permissions' => '644'
        ],
        [
            'name' => 'script.js',
            'type' => 'file',
            'size' => 1536,
            'modified' => time() - 7200,
            'permissions' => '644'
        ],
        [
            'name' => 'images',
            'type' => 'directory',
            'size' => 0,
            'modified' => time() - 86400,
            'permissions' => '755'
        ],
        [
            'name' => 'css',
            'type' => 'directory',
            'size' => 0,
            'modified' => time() - 172800,
            'permissions' => '755'
        ]
    ];
    
    // Add directory-specific files
    if ($directory === '/images') {
        return [
            [
                'name' => 'logo.png',
                'type' => 'file',
                'size' => 15360,
                'modified' => time() - 86400,
                'permissions' => '644'
            ],
            [
                'name' => 'banner.jpg',
                'type' => 'file',
                'size' => 51200,
                'modified' => time() - 172800,
                'permissions' => '644'
            ]
        ];
    } elseif ($directory === '/css') {
        return [
            [
                'name' => 'main.css',
                'type' => 'file',
                'size' => 4096,
                'modified' => time() - 3600,
                'permissions' => '644'
            ],
            [
                'name' => 'responsive.css',
                'type' => 'file',
                'size' => 2048,
                'modified' => time() - 7200,
                'permissions' => '644'
            ]
        ];
    }
    
    return $baseFiles;
}

function getFile($data) {
    session_start();
    if (!isset($_SESSION['ftp_connection'])) {
        return ['success' => false, 'error' => 'Not connected to FTP server'];
    }
    
    $filePath = $data['file_path'] ?? '';
    
    if (empty($filePath)) {
        return ['success' => false, 'error' => 'File path is required'];
    }
    
    // Generate mock file content based on file extension
    $content = generateMockFileContent($filePath);
    
    return [
        'success' => true,
        'content' => $content,
        'file_path' => $filePath
    ];
}

function generateMockFileContent($filePath) {
    $extension = pathinfo($filePath, PATHINFO_EXTENSION);
    
    switch (strtolower($extension)) {
        case 'php':
            return "<?php\n// Demo PHP file: " . basename($filePath) . "\necho 'Hello from " . basename($filePath) . "';\n?>";
        
        case 'html':
            return "<!DOCTYPE html>\n<html>\n<head>\n    <title>Demo Page</title>\n</head>\n<body>\n    <h1>Hello World</h1>\n    <p>This is a demo HTML file.</p>\n</body>\n</html>";
        
        case 'css':
            return "/* Demo CSS file: " . basename($filePath) . " */\nbody {\n    font-family: Arial, sans-serif;\n    margin: 0;\n    padding: 20px;\n}\n\nh1 {\n    color: #333;\n}";
        
        case 'js':
            return "// Demo JavaScript file: " . basename($filePath) . "\nconsole.log('Hello from " . basename($filePath) . "');\n\nfunction greet(name) {\n    return `Hello, ${name}!`;\n}";
        
        case 'json':
            return "{\n    \"name\": \"Demo Project\",\n    \"version\": \"1.0.0\",\n    \"description\": \"A demo configuration file\"\n}";
        
        default:
            return "// Demo file: " . basename($filePath) . "\n// Content loaded from FTP server\n// Last modified: " . date('Y-m-d H:i:s');
    }
}

function putFile($data) {
    session_start();
    if (!isset($_SESSION['ftp_connection'])) {
        return ['success' => false, 'error' => 'Not connected to FTP server'];
    }
    
    $filePath = $data['file_path'] ?? '';
    $content = $data['content'] ?? '';
    
    if (empty($filePath)) {
        return ['success' => false, 'error' => 'File path is required'];
    }
    
    // Simulate file upload
    // In real implementation, you would use ftp_put() or ftp_fput()
    
    // Simulate some validation
    if (strlen($content) > 1048576) { // 1MB limit for demo
        return ['success' => false, 'error' => 'File too large (max 1MB)'];
    }
    
    // Simulate save delay
    usleep(100000); // 0.1 second
    
    return [
        'success' => true,
        'message' => 'File saved successfully',
        'file_path' => $filePath,
        'size' => strlen($content)
    ];
}

function createDirectory($data) {
    session_start();
    if (!isset($_SESSION['ftp_connection'])) {
        return ['success' => false, 'error' => 'Not connected to FTP server'];
    }
    
    $directory = $data['directory'] ?? '';
    
    if (empty($directory)) {
        return ['success' => false, 'error' => 'Directory path is required'];
    }
    
    // Simulate directory creation
    return [
        'success' => true,
        'message' => 'Directory created successfully',
        'directory' => $directory
    ];
}

function deleteFile($data) {
    session_start();
    if (!isset($_SESSION['ftp_connection'])) {
        return ['success' => false, 'error' => 'Not connected to FTP server'];
    }
    
    $filePath = $data['file_path'] ?? '';
    
    if (empty($filePath)) {
        return ['success' => false, 'error' => 'File path is required'];
    }
    
    // Simulate file deletion
    return [
        'success' => true,
        'message' => 'File deleted successfully',
        'file_path' => $filePath
    ];
}

function renameFile($data) {
    session_start();
    if (!isset($_SESSION['ftp_connection'])) {
        return ['success' => false, 'error' => 'Not connected to FTP server'];
    }
    
    $oldPath = $data['old_path'] ?? '';
    $newPath = $data['new_path'] ?? '';
    
    if (empty($oldPath) || empty($newPath)) {
        return ['success' => false, 'error' => 'Both old and new paths are required'];
    }
    
    // Simulate file rename
    return [
        'success' => true,
        'message' => 'File renamed successfully',
        'old_path' => $oldPath,
        'new_path' => $newPath
    ];
}

function getPermissions($data) {
    session_start();
    if (!isset($_SESSION['ftp_connection'])) {
        return ['success' => false, 'error' => 'Not connected to FTP server'];
    }
    
    $filePath = $data['file_path'] ?? '';
    
    if (empty($filePath)) {
        return ['success' => false, 'error' => 'File path is required'];
    }
    
    // Simulate getting file permissions
    $extension = pathinfo($filePath, PATHINFO_EXTENSION);
    $permissions = in_array(strtolower($extension), ['php', 'cgi', 'sh']) ? '755' : '644';
    
    return [
        'success' => true,
        'permissions' => $permissions,
        'file_path' => $filePath
    ];
}

function setPermissions($data) {
    session_start();
    if (!isset($_SESSION['ftp_connection'])) {
        return ['success' => false, 'error' => 'Not connected to FTP server'];
    }
    
    $filePath = $data['file_path'] ?? '';
    $permissions = $data['permissions'] ?? '';
    
    if (empty($filePath) || empty($permissions)) {
        return ['success' => false, 'error' => 'File path and permissions are required'];
    }
    
    // Validate permissions format
    if (!preg_match('/^[0-7]{3}$/', $permissions)) {
        return ['success' => false, 'error' => 'Invalid permissions format (use 3-digit octal like 644 or 755)'];
    }
    
    // Simulate setting file permissions
    return [
        'success' => true,
        'message' => 'File permissions updated successfully',
        'file_path' => $filePath,
        'permissions' => $permissions
    ];
}

function testConnection($data) {
    $host = $data['host'] ?? '';
    $port = intval($data['port'] ?? 21);
    $username = $data['username'] ?? '';
    $password = $data['password'] ?? '';
    $secure = isset($data['secure']) && $data['secure'];
    
    // Validate input
    if (empty($host) || empty($username) || empty($password)) {
        return ['success' => false, 'message' => 'Host, username, and password are required'];
    }
    
    // Test connection without storing session data
    if (simulateFTPConnection($host, $port, $username, $password, $secure)) {
        return [
            'success' => true,
            'message' => 'Connection test successful',
            'server_info' => [
                'host' => $host,
                'port' => $port,
                'secure' => $secure,
                'server_type' => 'Demo FTP Server',
                'features' => ['PASV', 'SIZE', 'MDTM']
            ]
        ];
    } else {
        return ['success' => false, 'message' => 'Connection test failed'];
    }
}
?>