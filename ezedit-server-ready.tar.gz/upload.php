<?php
// EzEdit Deployment Uploader
// Upload this file to your server first, then use it to deploy EzEdit

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['ezedit_zip'])) {
    $uploadDir = './';
    $uploadFile = $uploadDir . 'ezedit-deployment.zip';
    
    echo "<h2>🚀 EzEdit Deployment</h2>";
    
    if (move_uploaded_file($_FILES['ezedit_zip']['tmp_name'], $uploadFile)) {
        echo "<p>✅ File uploaded successfully</p>";
        
        // Extract ZIP file
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive;
            $result = $zip->open($uploadFile);
            
            if ($result === TRUE) {
                $zip->extractTo('./');
                $zip->close();
                unlink($uploadFile); // Remove ZIP after extraction
                
                echo "<p>📦 EzEdit extracted successfully!</p>";
                echo "<p>🎉 <strong>Deployment Complete!</strong></p>";
                echo "<p>📍 Your EzEdit is now available at:</p>";
                echo "<ul>";
                echo "<li><a href='./index.php' target='_blank'>Homepage</a></li>";
                echo "<li><a href='./editor.php' target='_blank'>Code Editor</a></li>";
                echo "<li><a href='./dashboard.php' target='_blank'>Dashboard</a></li>";
                echo "<li><a href='./health.php' target='_blank'>Health Check</a></li>";
                echo "</ul>";
                
                echo "<hr><p><small>You can now delete this upload.php file for security.</small></p>";
            } else {
                echo "<p>❌ Failed to extract ZIP file</p>";
            }
        } else {
            echo "<p>❌ ZipArchive not available - please extract manually</p>";
        }
    } else {
        echo "<p>❌ Upload failed</p>";
    }
    
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>🚀 Deploy EzEdit</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .upload-area { border: 2px dashed #ccc; padding: 40px; text-align: center; margin: 20px 0; }
        button { background: #007cba; color: white; padding: 12px 24px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #005a87; }
        .instructions { background: #f8f9fa; padding: 20px; border-radius: 4px; margin: 20px 0; }
    </style>
</head>
<body>
    <h1>🚀 Deploy EzEdit to Your Server</h1>
    
    <div class="instructions">
        <h3>📋 Instructions:</h3>
        <ol>
            <li>Select the <code>ezedit-server-ready.zip</code> file below</li>
            <li>Click "Deploy EzEdit" to upload and extract</li>
            <li>Access your new code editor!</li>
        </ol>
    </div>
    
    <form enctype="multipart/form-data" method="post">
        <div class="upload-area">
            <p>📦 Select EzEdit Deployment Package:</p>
            <input type="file" name="ezedit_zip" accept=".zip" required style="margin: 10px;">
            <br><br>
            <button type="submit">🚀 Deploy EzEdit</button>
        </div>
    </form>
    
    <div class="instructions">
        <h3>🔧 What gets deployed:</h3>
        <ul>
            <li>💻 Monaco Code Editor with syntax highlighting</li>
            <li>📁 FTP/SFTP file manager</li>
            <li>🤖 AI-powered coding assistant</li>
            <li>📱 Responsive web interface</li>
            <li>🔐 User authentication system</li>
            <li>⚡ Real-time file synchronization</li>
        </ul>
    </div>
</body>
</html>