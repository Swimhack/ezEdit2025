<?php
/**
 * EzEdit.co - Main Editor Interface
 * Three-pane layout: File Explorer, Monaco Editor, AI Assistant
 */

session_start();

// Check if user is authenticated
$authenticated = isset($_SESSION['user_id']);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editor - EzEdit.co</title>
    
    <!-- Styles -->
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/editor.css">
    
    <!-- Monaco Editor -->
    <script src="https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs/loader.js"></script>
    
    <!-- Supabase -->
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
</head>
<body class="editor-layout">
    <!-- Header -->
    <header class="editor-header">
        <div class="header-left">
            <a href="index.php" class="logo">EzEdit.co</a>
            <div class="connection-status" id="connectionStatus">
                <span class="status-dot"></span>
                <span class="status-text">Not Connected</span>
            </div>
        </div>
        <div class="header-center">
            <div class="file-tabs" id="fileTabs">
                <!-- File tabs will be dynamically added here -->
            </div>
        </div>
        <div class="header-right">
            <button class="btn-icon" id="saveFile" title="Save (Ctrl+S)">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                    <polyline points="17,21 17,13 7,13 7,21"></polyline>
                    <polyline points="7,3 7,8 15,8"></polyline>
                </svg>
            </button>
            <?php if ($authenticated): ?>
                <button class="btn-secondary" id="userMenu">Account</button>
            <?php else: ?>
                <a href="auth/login.php" class="btn-secondary">Login</a>
            <?php endif; ?>
        </div>
    </header>

    <main class="editor-main">
        <!-- File Explorer Sidebar -->
        <aside class="file-explorer" id="fileExplorer">
            <div class="explorer-header">
                <h3>Explorer</h3>
                <div class="explorer-actions">
                    <button class="btn-icon" id="connectFTP" title="Connect to FTP">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path>
                            <polyline points="16,6 12,2 8,6"></polyline>
                            <line x1="12" y1="2" x2="12" y2="15"></line>
                        </svg>
                    </button>
                    <button class="btn-icon" id="refreshFiles" title="Refresh">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="23 4 23 10 17 10"></polyline>
                            <polyline points="1 20 1 14 7 14"></polyline>
                            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                        </svg>
                    </button>
                </div>
            </div>
            <div class="file-tree" id="fileTree">
                <div class="empty-state">
                    <p>Connect to FTP server to browse files</p>
                    <button class="btn-primary" id="connectButton">Connect</button>
                </div>
            </div>
        </aside>

        <!-- Main Editor Area -->
        <section class="editor-container">
            <div class="editor-wrapper">
                <div id="monacoEditor" class="monaco-editor-container"></div>
                <div class="editor-placeholder" id="editorPlaceholder">
                    <div class="placeholder-content">
                        <h2>Welcome to EzEdit.co</h2>
                        <p>Connect to your FTP server and select a file to start editing</p>
                        <div class="quick-actions">
                            <button class="btn-primary" id="quickConnect">Connect to FTP</button>
                            <button class="btn-secondary" id="openDemo">Try Demo</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- AI Assistant Sidebar -->
        <aside class="ai-assistant" id="aiAssistant">
            <div class="assistant-header">
                <h3>AI Assistant</h3>
                <div class="assistant-actions">
                    <button class="btn-icon" id="clearChat" title="Clear Chat">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3,6 5,6 21,6"></polyline>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                    </button>
                    <button class="btn-icon" id="toggleAssistant" title="Toggle Assistant">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="9,18 15,12 9,6"></polyline>
                        </svg>
                    </button>
                </div>
            </div>
            <div class="chat-container" id="chatContainer">
                <div class="chat-messages" id="chatMessages">
                    <div class="ai-message">
                        <div class="message-content">
                            <p>Hello! I'm your AI coding assistant. I can help you:</p>
                            <ul>
                                <li>Explain code functionality</li>
                                <li>Generate code snippets</li>
                                <li>Debug issues</li>
                                <li>Optimize performance</li>
                            </ul>
                            <p>Just select some code or ask me a question!</p>
                        </div>
                    </div>
                </div>
                <div class="chat-input">
                    <textarea id="chatInput" placeholder="Ask about your code or request help..."></textarea>
                    <button class="btn-primary" id="sendMessage">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="22" y1="2" x2="11" y2="13"></line>
                            <polygon points="22,2 15,22 11,13 2,9 22,2"></polygon>
                        </svg>
                    </button>
                </div>
            </div>
        </aside>
    </main>

    <!-- FTP Connection Modal -->
    <div class="modal" id="ftpModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Connect to FTP Server</h3>
                <button class="modal-close" id="closeFtpModal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="ftpForm">
                    <div class="form-group">
                        <label for="ftpHost">Server Host</label>
                        <input type="text" id="ftpHost" placeholder="ftp.example.com" required>
                    </div>
                    <div class="form-group">
                        <label for="ftpPort">Port</label>
                        <input type="number" id="ftpPort" value="21" required>
                    </div>
                    <div class="form-group">
                        <label for="ftpUsername">Username</label>
                        <input type="text" id="ftpUsername" required>
                    </div>
                    <div class="form-group">
                        <label for="ftpPassword">Password</label>
                        <input type="password" id="ftpPassword" required>
                    </div>
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="ftpSecure"> Use FTPS (Secure)
                        </label>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn-secondary" id="cancelConnect">Cancel</button>
                        <button type="submit" class="btn-primary">Connect</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="js/editor.js"></script>
    <script src="js/ftp-client.js"></script>
    <script src="js/ai-assistant.js"></script>
    <script>
        // Initialize editor when page loads
        document.addEventListener('DOMContentLoaded', function() {
            EzEditor.init();
        });
    </script>
</body>
</html>