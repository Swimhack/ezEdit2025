# ezEdit Authentication Logs

This directory contains detailed authentication logs for troubleshooting and monitoring.

## Log Files

### Main Log Files
- **`auth.log`** - Comprehensive log of all authentication events
- **`login.log`** - User login attempts (success and failures)
- **`signup.log`** - User registration attempts
- **`client-auth.log`** - Client-side authentication events
- **`errors.log`** - Authentication errors and failures

## Log Format

All logs are stored in JSON format for easy parsing and analysis:

```json
{
  "timestamp": "2025-06-23 21:22:00",
  "iso_timestamp": "2025-06-23T21:22:00-05:00",
  "action": "login_attempt",
  "status": "success",
  "email": "user@example.com",
  "ip_address": "192.168.1.100",
  "user_agent": "Mozilla/5.0...",
  "request_method": "POST",
  "request_uri": "/auth/auth-handler.php",
  "referer": "https://ezedit.co/login.html",
  "session_id": "sess_abc123",
  "additional_data": {
    "attempt_type": "login",
    "success": true,
    "user_data": {...},
    "execution_time": 0.045
  }
}
```

## Logged Events

### Server-Side Events (PHP)
- **Login attempts** (success/failure)
- **Registration attempts** (success/failure) 
- **Token verification** (success/failure)
- **Admin user detection**
- **Logout events**

### Client-Side Events (JavaScript)
- **Authentication method selection** (Supabase/PHP/OAuth)
- **Fallback authentication attempts**
- **Frontend authentication errors**
- **Session management events**

## Viewing Logs

### Admin Log Viewer
Access the web-based log viewer at:
```
/admin/log-viewer.php?admin_key=ezedit_admin_2025
```

Features:
- **Real-time log viewing** with auto-refresh
- **Filter by action, status, email**
- **Multiple log file selection**
- **Detailed JSON view** for each entry
- **Search and pagination**

### Command Line
View recent logs directly:
```bash
# View last 20 entries from auth.log
tail -20 logs/auth.log

# Follow live log updates
tail -f logs/auth.log

# Search for specific user
grep "user@example.com" logs/auth.log
```

## Security Considerations

- **Log files contain sensitive information** (emails, IPs, user agents)
- **Restrict access** to authorized administrators only
- **Regular log rotation** recommended for production
- **Monitor log file sizes** to prevent disk space issues

## Troubleshooting Common Issues

### Failed Login Attempts
1. Check `login.log` for error messages
2. Verify user credentials in database
3. Check IP blocking or rate limiting

### Registration Failures
1. Check `signup.log` for validation errors
2. Verify email format and domain restrictions
3. Check database connection issues

### OAuth Issues
1. Check `client-auth.log` for OAuth failures
2. Verify OAuth provider configuration
3. Check redirect URI settings

### Admin Access Issues
1. Check `auth.log` for admin detection events
2. Verify admin email domains in code
3. Check user role assignments

## Log Retention

- **Development**: Keep logs for 7 days
- **Production**: Keep logs for 30 days minimum
- **Compliance**: May require longer retention periods

## File Permissions

Ensure proper permissions:
```bash
chmod 755 logs/
chmod 644 logs/*.log
```

## Monitoring Alerts

Consider setting up alerts for:
- **High failed login rates** (potential brute force)
- **Admin access attempts** (security monitoring)
- **Authentication service failures** (system health)
- **Unusual IP patterns** (security monitoring)
