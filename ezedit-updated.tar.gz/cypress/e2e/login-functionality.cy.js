/**
 * Login Functionality Tests
 * Tests the login functionality including form validation, OAuth providers, and authentication flow
 */

describe('Login Page UI and Functionality', () => {
  beforeEach(() => {
    cy.visit('/login.html');
    
    // Clear localStorage before each test
    cy.clearLocalStorage();
  });

  it('should display the login page with standardized UI components', () => {
    // Check for header component
    cy.get('ez-header').should('exist');
    
    // Check for footer component
    cy.get('ez-footer').should('exist');
    
    // Check for login form
    cy.get('#login-form').should('exist');
    
    // Check for theme toggle
    cy.get('.theme-toggle').should('exist');
  });

  it('should have consistent styling with design tokens', () => {
    // Check that CSS variables are applied
    cy.get('body').should('have.css', 'font-family').and('include', 'Inter');
    
    // Check primary button styling
    cy.get('button[type="submit"]')
      .should('have.css', 'background-color')
      .and('not.be', 'rgba(0, 0, 0, 0)');
    
    // Check form control styling
    cy.get('.form-control')
      .should('have.css', 'border')
      .and('not.be', 'none');
  });

  it('should toggle password visibility', () => {
    // Password should be hidden by default
    cy.get('#password').should('have.attr', 'type', 'password');
    
    // Click toggle button
    cy.get('.password-toggle').click();
    
    // Password should now be visible
    cy.get('#password').should('have.attr', 'type', 'text');
    
    // Click toggle button again
    cy.get('.password-toggle').click();
    
    // Password should be hidden again
    cy.get('#password').should('have.attr', 'type', 'password');
  });

  it('should validate email format', () => {
    // Enter invalid email
    cy.get('#email').type('invalid-email');
    cy.get('#password').type('password123');
    
    // Try to submit
    cy.get('button[type="submit"]').click();
    
    // Check for validation error
    cy.get('#email:invalid').should('exist');
  });

  it('should show error for empty fields', () => {
    // Try to submit empty form
    cy.get('button[type="submit"]').click();
    
    // Check for validation errors
    cy.get('#email:invalid').should('exist');
    cy.get('#password:invalid').should('exist');
  });

  it('should handle login form submission', () => {
    // Stub the Supabase signIn method
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = win.ezEdit.supabase || {};
      win.ezEdit.supabase.signIn = cy.stub().as('signIn').resolves({
        user: { email: 'test@example.com' }
      });
      
      // Stub location.href to check redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Fill in the form
    cy.get('#email').type('test@example.com');
    cy.get('#password').type('password123');
    
    // Submit the form
    cy.get('button[type="submit"]').click();
    
    // Check that signIn was called with correct parameters
    cy.get('@signIn').should('be.calledWith', 'test@example.com', 'password123');
    
    // Check redirect to dashboard
    cy.get('@locationHref').should('contain', '/dashboard.html');
  });

  it('should handle login error', () => {
    // Stub the Supabase signIn method to return error
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = win.ezEdit.supabase || {};
      win.ezEdit.supabase.signIn = cy.stub().as('signIn').rejects(new Error('Invalid login credentials'));
    });
    
    // Fill in the form
    cy.get('#email').type('test@example.com');
    cy.get('#password').type('wrongpassword');
    
    // Submit the form
    cy.get('button[type="submit"]').click();
    
    // Check that error message is displayed
    cy.get('#login-error').should('be.visible');
    cy.get('#login-error').should('contain', 'Invalid login credentials');
  });

  it('should handle Google OAuth login', () => {
    // Stub the Supabase signInWithProvider method
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = win.ezEdit.supabase || {};
      win.ezEdit.supabase.signInWithProvider = cy.stub().as('signInWithProvider');
    });
    
    // Click Google login button
    cy.get('.btn-google').click();
    
    // Check that signInWithProvider was called with correct provider
    cy.get('@signInWithProvider').should('be.calledWith', 'google');
  });

  it('should handle GitHub OAuth login', () => {
    // Stub the Supabase signInWithProvider method
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = win.ezEdit.supabase || {};
      win.ezEdit.supabase.signInWithProvider = cy.stub().as('signInWithProvider');
    });
    
    // Click GitHub login button
    cy.get('.btn-github').click();
    
    // Check that signInWithProvider was called with correct provider
    cy.get('@signInWithProvider').should('be.calledWith', 'github');
  });

  it('should display OAuth error messages', () => {
    // Simulate OAuth error in URL
    cy.visit('/login.html?error=access_denied&error_description=User%20denied%20access');
    
    // Check that error message is displayed
    cy.get('#login-error').should('be.visible');
    cy.get('#login-error').should('contain', 'User denied access');
  });

  it('should redirect authenticated users to dashboard', () => {
    // Stub authentication to return true
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = win.ezEdit.supabase || {};
      win.ezEdit.supabase.isAuthenticated = cy.stub().returns(true);
      
      // Stub location.href to check redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Reload page to trigger authentication check
    cy.reload();
    
    // Check redirect to dashboard
    cy.get('@locationHref').should('contain', '/dashboard.html');
  });

  it('should toggle dark mode', () => {
    // Body should not have dark-mode class initially
    cy.get('body').should('not.have.class', 'dark-mode');
    
    // Click theme toggle button
    cy.get('.theme-toggle').click();
    
    // Body should have dark-mode class
    cy.get('body').should('have.class', 'dark-mode');
    
    // Check if dark mode is persisted in localStorage
    cy.window().then((win) => {
      expect(win.localStorage.getItem('ezEditDarkMode')).to.eq('true');
    });
  });

  it('should show toast notifications', () => {
    // Stub the UI showToast method
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.ui = win.ezEdit.ui || {};
      win.ezEdit.ui.showToast = cy.stub().as('showToast');
      
      // Stub the Supabase signIn method to return error
      win.ezEdit.supabase = win.ezEdit.supabase || {};
      win.ezEdit.supabase.signIn = cy.stub().rejects(new Error('Invalid login credentials'));
    });
    
    // Fill in the form
    cy.get('#email').type('test@example.com');
    cy.get('#password').type('wrongpassword');
    
    // Submit the form
    cy.get('button[type="submit"]').click();
    
    // Check that showToast was called
    cy.get('@showToast').should('be.called');
  });
});

describe('Auth Callback Page', () => {
  it('should handle successful authentication', () => {
    // Mock hash parameters for successful auth
    cy.visit('/auth-callback.html#access_token=mock_token&token_type=bearer&expires_in=3600');
    
    // Stub Supabase auth methods
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = win.ezEdit.supabase || {};
      win.ezEdit.supabase.client = {
        auth: {
          setSession: cy.stub().resolves({
            session: {
              user: { email: 'test@example.com', id: 'user123' },
              access_token: 'mock_token',
              expires_at: new Date(Date.now() + 3600000).toISOString()
            }
          })
        }
      };
      
      // Stub location.href to check redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Check for loading spinner
    cy.get('.loading-spinner').should('exist');
    
    // Check for status message
    cy.get('#status-message').should('exist');
    
    // Check that it will redirect to dashboard
    cy.get('@locationHref', { timeout: 2000 }).should('contain', '/dashboard.html');
  });

  it('should handle authentication error', () => {
    // Mock hash parameters for auth error
    cy.visit('/auth-callback.html#error=access_denied&error_description=User%20denied%20access');
    
    // Stub location.href to check redirect
    cy.window().then((win) => {
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Check for error status message
    cy.get('#status-message').should('have.class', 'error');
    cy.get('#status-message').should('contain', 'User denied access');
    
    // Check that it will redirect to login with error
    cy.get('@locationHref', { timeout: 3500 }).should('contain', '/login.html?error=');
  });
});
