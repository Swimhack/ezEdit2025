describe('UI Consistency Tests', () => {
  const pages = [
    '/',
    '/login.html',
    '/signup.html',
    '/dashboard.html'
  ];

  // Test for consistent header elements across pages
  it('should have consistent logo styling across all pages', () => {
    pages.forEach(page => {
      cy.visit(page);
      cy.get('.logo').should('exist');
      cy.get('.logo-icon').should('have.text', 'Ez');
      cy.get('.logo-text').should('have.text', 'Edit.co');
      
      // Check logo styling
      cy.get('.logo-icon').should('have.css', 'color', 'rgb(37, 99, 235)'); // Primary blue
    });
  });

  // Test for consistent button styling
  it('should have consistent primary button styling', () => {
    cy.visit('/');
    cy.get('.btn').first().should('have.css', 'background-color', 'rgb(37, 99, 235)'); // Primary blue
    cy.get('.btn').first().should('have.css', 'color', 'rgb(255, 255, 255)'); // White text
    cy.get('.btn').first().should('have.css', 'border-radius', '6px'); // 0.375rem
    
    cy.visit('/login.html');
    cy.get('.btn').first().should('have.css', 'background-color', 'rgb(37, 99, 235)'); // Primary blue
    cy.get('.btn').first().should('have.css', 'color', 'rgb(255, 255, 255)'); // White text
    cy.get('.btn').first().should('have.css', 'border-radius', '6px'); // 0.375rem
  });

  // Test for consistent card styling
  it('should have consistent card styling', () => {
    cy.visit('/');
    cy.get('.card').first().should('have.css', 'background-color', 'rgb(255, 255, 255)'); // White
    cy.get('.card').first().should('have.css', 'border-radius', '8px'); // 0.5rem
    
    cy.visit('/dashboard.html');
    cy.get('.card').first().should('have.css', 'background-color', 'rgb(255, 255, 255)'); // White
    cy.get('.card').first().should('have.css', 'border-radius', '8px'); // 0.5rem
  });

  // Test for consistent form styling
  it('should have consistent form input styling', () => {
    cy.visit('/login.html');
    cy.get('input[type="email"]').should('have.css', 'border', '1px solid rgb(229, 231, 235)');
    cy.get('input[type="email"]').should('have.css', 'border-radius', '6px'); // 0.375rem
    
    cy.visit('/signup.html');
    cy.get('input[type="email"]').should('have.css', 'border', '1px solid rgb(229, 231, 235)');
    cy.get('input[type="email"]').should('have.css', 'border-radius', '6px'); // 0.375rem
  });

  // Test for responsive behavior
  it('should have responsive navigation on mobile', () => {
    cy.viewport('iphone-x');
    cy.visit('/');
    cy.get('.nav-main').should('not.be.visible');
    
    cy.viewport(1024, 768);
    cy.visit('/');
    cy.get('.nav-main').should('be.visible');
  });
});
