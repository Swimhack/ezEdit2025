/**
 * Theme Toggle Functionality Tests
 * Tests the theme toggle functionality across all pages to ensure consistent behavior
 */

describe('Theme Toggle Functionality', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
  });

  it('should toggle theme on homepage', () => {
    // Visit homepage
    cy.visit('/');
    
    // Body should not have dark-mode class initially
    cy.get('body').should('not.have.class', 'dark-mode');
    
    // Find and click theme toggle button
    cy.get('.theme-toggle').click();
    
    // Body should have dark-mode class after toggle
    cy.get('body').should('have.class', 'dark-mode');
    
    // Check if dark mode is persisted in localStorage
    cy.window().then((win) => {
      expect(win.localStorage.getItem('ezEditDarkMode')).to.eq('true');
    });
    
    // Click toggle button again
    cy.get('.theme-toggle').click();
    
    // Body should not have dark-mode class after toggling back
    cy.get('body').should('not.have.class', 'dark-mode');
    
    // Check if light mode is persisted in localStorage
    cy.window().then((win) => {
      expect(win.localStorage.getItem('ezEditDarkMode')).to.eq('false');
    });
  });

  it('should persist theme across page navigation', () => {
    // Set dark mode in localStorage
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'true');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Body should have dark-mode class
    cy.get('body').should('have.class', 'dark-mode');
    
    // Visit login page
    cy.visit('/login.html');
    
    // Body should still have dark-mode class
    cy.get('body').should('have.class', 'dark-mode');
    
    // Visit signup page
    cy.visit('/signup.html');
    
    // Body should still have dark-mode class
    cy.get('body').should('have.class', 'dark-mode');
  });

  it('should apply dark mode CSS variables', () => {
    // Set dark mode in localStorage
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'true');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Check that dark mode CSS variables are applied
    cy.get('body').should('have.css', 'background-color').and('not.eq', 'rgb(255, 255, 255)');
    
    // Check text color in dark mode
    cy.get('body').should('have.css', 'color').and('not.eq', 'rgb(0, 0, 0)');
  });

  it('should toggle theme on login page', () => {
    // Visit login page
    cy.visit('/login.html');
    
    // Body should not have dark-mode class initially
    cy.get('body').should('not.have.class', 'dark-mode');
    
    // Find and click theme toggle button
    cy.get('.theme-toggle').click();
    
    // Body should have dark-mode class after toggle
    cy.get('body').should('have.class', 'dark-mode');
    
    // Check form elements in dark mode
    cy.get('.form-control').should('have.css', 'background-color').and('not.eq', 'rgb(255, 255, 255)');
  });

  it('should toggle theme on signup page', () => {
    // Visit signup page
    cy.visit('/signup.html');
    
    // Body should not have dark-mode class initially
    cy.get('body').should('not.have.class', 'dark-mode');
    
    // Find and click theme toggle button
    cy.get('.theme-toggle').click();
    
    // Body should have dark-mode class after toggle
    cy.get('body').should('have.class', 'dark-mode');
    
    // Check form elements in dark mode
    cy.get('.form-control').should('have.css', 'background-color').and('not.eq', 'rgb(255, 255, 255)');
  });

  it('should toggle theme on dashboard page', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Body should not have dark-mode class initially
    cy.get('body').should('not.have.class', 'dark-mode');
    
    // Find and click theme toggle button
    cy.get('.theme-toggle').click();
    
    // Body should have dark-mode class after toggle
    cy.get('body').should('have.class', 'dark-mode');
    
    // Check card elements in dark mode
    cy.get('.card').should('have.css', 'background-color').and('not.eq', 'rgb(255, 255, 255)');
  });

  it('should initialize theme from system preference', () => {
    // Mock system preference for dark mode
    cy.window().then((win) => {
      // Create a mock matchMedia function that returns dark mode preference
      win.matchMedia = (query) => ({
        matches: query === '(prefers-color-scheme: dark)',
        addEventListener: () => {},
        removeEventListener: () => {}
      });
      
      // Clear any existing preference
      win.localStorage.removeItem('ezEditDarkMode');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Body should have dark-mode class based on system preference
    cy.get('body').should('have.class', 'dark-mode');
  });

  it('should update theme when system preference changes', () => {
    // Set up event listeners and system preference mocking
    cy.window().then((win) => {
      // Start with light mode preference
      let darkModePreference = false;
      
      // Create a mock matchMedia function
      win.matchMedia = (query) => {
        const result = {
          matches: query === '(prefers-color-scheme: dark)' ? darkModePreference : false,
          addEventListener: (event, listener) => {
            // Store the listener to trigger later
            result.listener = listener;
          },
          removeEventListener: () => {}
        };
        return result;
      };
      
      // Store the matchMedia result to access later
      win.darkModeMediaQuery = win.matchMedia('(prefers-color-scheme: dark)');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Body should not have dark-mode class initially
    cy.get('body').should('not.have.class', 'dark-mode');
    
    // Simulate system preference change
    cy.window().then((win) => {
      // Change preference to dark mode
      win.darkModeMediaQuery.matches = true;
      
      // Trigger the event
      if (win.darkModeMediaQuery.listener) {
        win.darkModeMediaQuery.listener({ matches: true });
      }
    });
    
    // Body should have dark-mode class after preference change
    cy.get('body').should('have.class', 'dark-mode');
  });

  it('should apply consistent styling in dark mode across pages', () => {
    // Set dark mode in localStorage
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'true');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Get background color in dark mode
    cy.get('body').invoke('css', 'background-color').then((homepageColor) => {
      // Visit login page
      cy.visit('/login.html');
      
      // Check that background color is the same
      cy.get('body').should('have.css', 'background-color', homepageColor);
      
      // Visit signup page
      cy.visit('/signup.html');
      
      // Check that background color is the same
      cy.get('body').should('have.css', 'background-color', homepageColor);
    });
  });

  it('should apply consistent button styling in dark mode', () => {
    // Set dark mode in localStorage
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'true');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Get primary button background color
    cy.get('.btn-primary').first().invoke('css', 'background-color').then((btnColor) => {
      // Visit login page
      cy.visit('/login.html');
      
      // Check that button background color is the same
      cy.get('.btn-primary').first().should('have.css', 'background-color', btnColor);
    });
  });
});
