/**
 * Dashboard Functionality Tests
 * Tests the dashboard page functionality including authentication guard, site display, and user interactions
 */

describe('Dashboard Authentication and UI', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
  });

  it('should redirect unauthenticated users to login page', () => {
    // Stub authentication to return false
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(false)
      };
      
      // Stub location.href to check redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check redirect to login
    cy.get('@locationHref').should('contain', '/login.html');
  });

  it('should display user information when authenticated', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      // Mock authentication data
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: {
          email: 'test@example.com',
          firstName: 'Test',
          lastName: 'User',
          plan: 'free-trial',
          trialDaysLeft: 7
        }
      }));
      
      // Stub authentication methods
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({
          email: 'test@example.com',
          firstName: 'Test',
          lastName: 'User'
        })
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check for user email in header
    cy.get('.user-info').should('contain', 'test@example.com');
    
    // Check for dashboard header
    cy.get('.dashboard-header').should('exist');
    cy.get('.dashboard-header').should('contain', 'My Sites');
  });

  it('should have consistent header and footer', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' })
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check for header component
    cy.get('ez-header').should('exist');
    cy.get('.logo-icon').should('contain', 'Ez');
    
    // Check for footer component
    cy.get('ez-footer').should('exist');
    cy.get('.footer-content').should('exist');
  });

  it('should display empty state when no sites exist', () => {
    // Set up mock authenticated user with no sites
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check for empty state message
    cy.get('.sites-container').should('contain', 'No sites found');
    
    // Check for add site button
    cy.get('#add-site-btn').should('exist');
  });

  it('should display site cards when sites exist', () => {
    // Mock sites data
    const mockSites = [
      {
        id: 'site1',
        name: 'Test Site 1',
        host: 'ftp.test1.com',
        last_accessed: new Date().toISOString()
      },
      {
        id: 'site2',
        name: 'Test Site 2',
        host: 'ftp.test2.com',
        last_accessed: new Date(Date.now() - 86400000).toISOString()
      }
    ];
    
    // Set up mock authenticated user with sites
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves(mockSites)
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check for site cards
    cy.get('.site-card').should('have.length', 2);
    cy.get('.site-card').first().should('contain', 'Test Site 1');
    cy.get('.site-card').first().should('contain', 'ftp.test1.com');
  });

  it('should handle site card actions', () => {
    // Mock sites data
    const mockSites = [
      {
        id: 'site1',
        name: 'Test Site 1',
        host: 'ftp.test1.com',
        last_accessed: new Date().toISOString()
      }
    ];
    
    // Set up mock authenticated user with sites
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves(mockSites)
      };
      
      // Stub location.href to check redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check for edit button and click it
    cy.get('.site-card .btn-edit').first().click();
    
    // Check redirect to editor
    cy.get('@locationHref').should('contain', '/editor.html?site=site1');
  });

  it('should handle site settings button', () => {
    // Mock sites data
    const mockSites = [
      {
        id: 'site1',
        name: 'Test Site 1',
        host: 'ftp.test1.com',
        last_accessed: new Date().toISOString()
      }
    ];
    
    // Set up mock authenticated user with sites
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves(mockSites)
      };
      
      // Stub location.href to check redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check for settings button and click it
    cy.get('.site-card .btn-settings').first().click();
    
    // Check redirect to site settings
    cy.get('@locationHref').should('contain', '/site-settings.html?site=site1');
  });

  it('should handle add site button', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([])
      };
      
      // Stub location.href to check redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check for add site button and click it
    cy.get('#add-site-btn').click();
    
    // Check redirect to add site page
    cy.get('@locationHref').should('contain', '/add-site.html');
  });

  it('should handle logout button', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([]),
        signOut: cy.stub().as('signOut').resolves(true)
      };
      
      // Stub location.href to check redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Open user menu
    cy.get('.user-menu-toggle').click();
    
    // Click logout button
    cy.get('.logout-btn').click();
    
    // Check that signOut was called
    cy.get('@signOut').should('be.called');
    
    // Check redirect to home page
    cy.get('@locationHref').should('eq', '/');
  });

  it('should toggle dark mode', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Body should not have dark-mode class initially
    cy.get('body').should('not.have.class', 'dark-mode');
    
    // Click theme toggle button
    cy.get('.theme-toggle').click();
    
    // Body should have dark-mode class
    cy.get('body').should('have.class', 'dark-mode');
    
    // Check if dark mode is persisted in localStorage
    cy.window().then((win) => {
      expect(win.localStorage.getItem('ezEditDarkMode')).to.eq('true');
    });
  });

  it('should display trial information for free-trial users', () => {
    // Set up mock authenticated user with free-trial plan
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: {
          email: 'test@example.com',
          firstName: 'Test',
          lastName: 'User',
          plan: 'free-trial',
          trialDaysLeft: 5
        }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({
          email: 'test@example.com',
          firstName: 'Test',
          lastName: 'User',
          plan: 'free-trial',
          trialDaysLeft: 5
        }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check for trial banner
    cy.get('.trial-banner').should('exist');
    cy.get('.trial-banner').should('contain', '5 days');
    cy.get('.upgrade-btn').should('exist');
  });

  it('should not display trial banner for pro users', () => {
    // Set up mock authenticated user with pro plan
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: {
          email: 'test@example.com',
          firstName: 'Test',
          lastName: 'User',
          plan: 'pro'
        }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({
          email: 'test@example.com',
          firstName: 'Test',
          lastName: 'User',
          plan: 'pro'
        }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Trial banner should not exist
    cy.get('.trial-banner').should('not.exist');
  });
});
