/**
 * Toast Notification Tests
 * Tests the toast notification system across all pages to ensure consistent behavior
 */

describe('Toast Notification System', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
    
    // Visit homepage
    cy.visit('/');
    
    // Set up toast notification system
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.ui = win.ezEdit.ui || {};
      
      // Make sure the toast container exists
      if (!win.document.querySelector('.toast-container')) {
        const toastContainer = win.document.createElement('div');
        toastContainer.className = 'toast-container';
        win.document.body.appendChild(toastContainer);
      }
    });
  });

  it('should show success toast notification', () => {
    // Call showToast with success type
    cy.window().then((win) => {
      win.ezEdit.ui.showToast('Operation successful', 'success');
    });
    
    // Check that toast is displayed
    cy.get('.toast').should('exist');
    cy.get('.toast').should('have.class', 'toast-success');
    cy.get('.toast').should('contain', 'Operation successful');
    
    // Check that toast has the correct styling
    cy.get('.toast.toast-success').should('have.css', 'background-color');
  });

  it('should show error toast notification', () => {
    // Call showToast with error type
    cy.window().then((win) => {
      win.ezEdit.ui.showToast('Operation failed', 'error');
    });
    
    // Check that toast is displayed
    cy.get('.toast').should('exist');
    cy.get('.toast').should('have.class', 'toast-error');
    cy.get('.toast').should('contain', 'Operation failed');
    
    // Check that toast has the correct styling
    cy.get('.toast.toast-error').should('have.css', 'background-color');
  });

  it('should show warning toast notification', () => {
    // Call showToast with warning type
    cy.window().then((win) => {
      win.ezEdit.ui.showToast('Warning message', 'warning');
    });
    
    // Check that toast is displayed
    cy.get('.toast').should('exist');
    cy.get('.toast').should('have.class', 'toast-warning');
    cy.get('.toast').should('contain', 'Warning message');
    
    // Check that toast has the correct styling
    cy.get('.toast.toast-warning').should('have.css', 'background-color');
  });

  it('should show info toast notification', () => {
    // Call showToast with info type
    cy.window().then((win) => {
      win.ezEdit.ui.showToast('Information message', 'info');
    });
    
    // Check that toast is displayed
    cy.get('.toast').should('exist');
    cy.get('.toast').should('have.class', 'toast-info');
    cy.get('.toast').should('contain', 'Information message');
    
    // Check that toast has the correct styling
    cy.get('.toast.toast-info').should('have.css', 'background-color');
  });

  it('should auto-dismiss toast after timeout', () => {
    // Set a short timeout for testing
    cy.window().then((win) => {
      win.ezEdit.ui.toastTimeout = 1000; // 1 second
      win.ezEdit.ui.showToast('Auto-dismiss test', 'info');
    });
    
    // Check that toast is displayed
    cy.get('.toast').should('exist');
    
    // Wait for toast to disappear
    cy.wait(1500);
    
    // Check that toast is no longer displayed
    cy.get('.toast').should('not.exist');
  });

  it('should dismiss toast when close button is clicked', () => {
    // Call showToast
    cy.window().then((win) => {
      win.ezEdit.ui.showToast('Click to dismiss', 'info');
    });
    
    // Check that toast is displayed
    cy.get('.toast').should('exist');
    
    // Click close button
    cy.get('.toast .toast-close').click();
    
    // Check that toast is no longer displayed
    cy.get('.toast').should('not.exist');
  });

  it('should stack multiple toast notifications', () => {
    // Call showToast multiple times
    cy.window().then((win) => {
      win.ezEdit.ui.showToast('First notification', 'success');
      win.ezEdit.ui.showToast('Second notification', 'error');
      win.ezEdit.ui.showToast('Third notification', 'warning');
    });
    
    // Check that all toasts are displayed
    cy.get('.toast').should('have.length', 3);
    
    // Check that toasts have the correct content
    cy.get('.toast').eq(0).should('contain', 'First notification');
    cy.get('.toast').eq(1).should('contain', 'Second notification');
    cy.get('.toast').eq(2).should('contain', 'Third notification');
  });

  it('should work on login page', () => {
    // Visit login page
    cy.visit('/login.html');
    
    // Call showToast
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.ui = win.ezEdit.ui || {};
      win.ezEdit.ui.showToast('Login page toast', 'info');
    });
    
    // Check that toast is displayed
    cy.get('.toast').should('exist');
    cy.get('.toast').should('contain', 'Login page toast');
  });

  it('should work on signup page', () => {
    // Visit signup page
    cy.visit('/signup.html');
    
    // Call showToast
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.ui = win.ezEdit.ui || {};
      win.ezEdit.ui.showToast('Signup page toast', 'info');
    });
    
    // Check that toast is displayed
    cy.get('.toast').should('exist');
    cy.get('.toast').should('contain', 'Signup page toast');
  });

  it('should work on dashboard page', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Call showToast
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.ui = win.ezEdit.ui || {};
      win.ezEdit.ui.showToast('Dashboard page toast', 'info');
    });
    
    // Check that toast is displayed
    cy.get('.toast').should('exist');
    cy.get('.toast').should('contain', 'Dashboard page toast');
  });

  it('should have consistent styling in light mode', () => {
    // Ensure light mode
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'false');
      win.document.body.classList.remove('dark-mode');
    });
    
    // Call showToast
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.ui = win.ezEdit.ui || {};
      win.ezEdit.ui.showToast('Light mode toast', 'info');
    });
    
    // Get toast background color
    cy.get('.toast').invoke('css', 'background-color').then((lightModeColor) => {
      // Remember the color
      cy.wrap(lightModeColor).as('lightModeColor');
    });
    
    // Visit login page
    cy.visit('/login.html');
    
    // Call showToast
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.ui = win.ezEdit.ui || {};
      win.ezEdit.ui.showToast('Light mode toast on login', 'info');
    });
    
    // Check that toast has the same background color
    cy.get('@lightModeColor').then((lightModeColor) => {
      cy.get('.toast').should('have.css', 'background-color', lightModeColor);
    });
  });

  it('should have consistent styling in dark mode', () => {
    // Enable dark mode
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'true');
      win.document.body.classList.add('dark-mode');
    });
    
    // Call showToast
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.ui = win.ezEdit.ui || {};
      win.ezEdit.ui.showToast('Dark mode toast', 'info');
    });
    
    // Get toast background color
    cy.get('.toast').invoke('css', 'background-color').then((darkModeColor) => {
      // Remember the color
      cy.wrap(darkModeColor).as('darkModeColor');
    });
    
    // Visit login page
    cy.visit('/login.html');
    
    // Enable dark mode again (since we navigated)
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'true');
      win.document.body.classList.add('dark-mode');
    });
    
    // Call showToast
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.ui = win.ezEdit.ui || {};
      win.ezEdit.ui.showToast('Dark mode toast on login', 'info');
    });
    
    // Check that toast has the same background color
    cy.get('@darkModeColor').then((darkModeColor) => {
      cy.get('.toast').should('have.css', 'background-color', darkModeColor);
    });
  });
});
