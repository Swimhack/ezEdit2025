/**
 * Authentication Flow Tests
 * Tests the complete authentication flow including signup, login, session management,
 * and OAuth providers integration with Supabase
 */

describe('Authentication Flow', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
    
    // Reset any previous stubs
    cy.window().then((win) => {
      if (win.ezEdit && win.ezEdit.supabase) {
        delete win.ezEdit.supabase;
      }
    });
  });

  it('should allow a new user to sign up with email and password', () => {
    // Setup stub for Supabase signUp
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signUp: cy.stub().as('signUp').resolves({
          data: { user: { id: 'test-user-id', email: 'newuser@example.com' } },
          error: null
        }),
        createProfile: cy.stub().resolves({ error: null })
      };
    });
    
    // Visit signup page
    cy.visit('/signup.html');
    
    // Fill in signup form
    cy.get('input[name="email"]').type('newuser@example.com');
    cy.get('input[name="password"]').type('SecurePassword123!');
    cy.get('input[name="confirmPassword"]').type('SecurePassword123!');
    
    // Submit form
    cy.get('form').submit();
    
    // Check that signUp was called with correct parameters
    cy.get('@signUp').should('be.calledWith', {
      email: 'newuser@example.com',
      password: 'SecurePassword123!'
    });
    
    // Check for success toast
    cy.get('.toast-success').should('be.visible');
    cy.get('.toast-success').should('contain', 'Account created');
    
    // Check for email verification message
    cy.get('.verification-message').should('be.visible');
    cy.get('.verification-message').should('contain', 'verification email');
  });

  it('should show validation errors during signup', () => {
    // Visit signup page
    cy.visit('/signup.html');
    
    // Submit empty form
    cy.get('form').submit();
    
    // Check for validation errors
    cy.get('.error-message').should('be.visible');
    
    // Fill with invalid email
    cy.get('input[name="email"]').type('invalid-email');
    cy.get('form').submit();
    
    // Check for email validation error
    cy.get('.error-message').should('contain', 'valid email');
    
    // Fill with short password
    cy.get('input[name="email"]').clear().type('valid@example.com');
    cy.get('input[name="password"]').type('short');
    cy.get('form').submit();
    
    // Check for password validation error
    cy.get('.error-message').should('contain', 'password');
    
    // Fill with mismatched passwords
    cy.get('input[name="password"]').clear().type('SecurePassword123!');
    cy.get('input[name="confirmPassword"]').type('DifferentPassword123!');
    cy.get('form').submit();
    
    // Check for password match error
    cy.get('.error-message').should('contain', 'match');
  });

  it('should handle signup errors from Supabase', () => {
    // Setup stub for Supabase signUp with error
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signUp: cy.stub().as('signUp').resolves({
          data: null,
          error: { message: 'Email already in use' }
        })
      };
    });
    
    // Visit signup page
    cy.visit('/signup.html');
    
    // Fill in signup form
    cy.get('input[name="email"]').type('existing@example.com');
    cy.get('input[name="password"]').type('SecurePassword123!');
    cy.get('input[name="confirmPassword"]').type('SecurePassword123!');
    
    // Submit form
    cy.get('form').submit();
    
    // Check for error toast
    cy.get('.toast-error').should('be.visible');
    cy.get('.toast-error').should('contain', 'Email already in use');
  });

  it('should allow a user to log in with email and password', () => {
    // Setup stub for Supabase signIn
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signIn: cy.stub().as('signIn').resolves({
          data: { 
            user: { id: 'test-user-id', email: 'user@example.com' },
            session: { access_token: 'test-token' }
          },
          error: null
        }),
        getProfile: cy.stub().resolves({
          data: { id: 'test-profile-id', user_id: 'test-user-id' },
          error: null
        })
      };
      
      // Stub location.href for redirect check
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Visit login page
    cy.visit('/login.html');
    
    // Fill in login form
    cy.get('input[name="email"]').type('user@example.com');
    cy.get('input[name="password"]').type('SecurePassword123!');
    
    // Submit form
    cy.get('form').submit();
    
    // Check that signIn was called with correct parameters
    cy.get('@signIn').should('be.calledWith', {
      email: 'user@example.com',
      password: 'SecurePassword123!'
    });
    
    // Check that user is redirected to dashboard
    cy.get('@locationHref').should('eq', '/dashboard.html');
    
    // Check that auth data is stored in localStorage
    cy.window().then((win) => {
      const authData = JSON.parse(win.localStorage.getItem('ezEditAuth'));
      expect(authData).to.have.property('isAuthenticated', true);
      expect(authData).to.have.property('user');
      expect(authData.user).to.have.property('email', 'user@example.com');
    });
  });

  it('should handle login errors from Supabase', () => {
    // Setup stub for Supabase signIn with error
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signIn: cy.stub().as('signIn').resolves({
          data: null,
          error: { message: 'Invalid login credentials' }
        })
      };
    });
    
    // Visit login page
    cy.visit('/login.html');
    
    // Fill in login form
    cy.get('input[name="email"]').type('wrong@example.com');
    cy.get('input[name="password"]').type('WrongPassword123!');
    
    // Submit form
    cy.get('form').submit();
    
    // Check for error toast
    cy.get('.toast-error').should('be.visible');
    cy.get('.toast-error').should('contain', 'Invalid login credentials');
    
    // Check that user is not redirected
    cy.url().should('include', '/login.html');
  });

  it('should allow a user to log in with Google OAuth', () => {
    // Setup stub for Supabase OAuth
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signInWithOAuth: cy.stub().as('signInWithOAuth').resolves({
          data: { provider: 'google', url: 'https://oauth.redirect.url' },
          error: null
        })
      };
      
      // Stub window.open for OAuth popup
      cy.stub(win, 'open').as('windowOpen');
    });
    
    // Visit login page
    cy.visit('/login.html');
    
    // Click Google OAuth button
    cy.get('button[data-provider="google"]').click();
    
    // Check that signInWithOAuth was called with correct parameters
    cy.get('@signInWithOAuth').should('be.calledWith', {
      provider: 'google',
      options: {
        redirectTo: Cypress.sinon.match.string
      }
    });
    
    // Check that OAuth window was opened
    cy.get('@windowOpen').should('be.calledWith', 
      'https://oauth.redirect.url', 
      '_self'
    );
  });

  it('should handle OAuth errors', () => {
    // Setup stub for Supabase OAuth with error
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signInWithOAuth: cy.stub().as('signInWithOAuth').resolves({
          data: null,
          error: { message: 'OAuth configuration error' }
        })
      };
    });
    
    // Visit login page
    cy.visit('/login.html');
    
    // Click Google OAuth button
    cy.get('button[data-provider="google"]').click();
    
    // Check for error toast
    cy.get('.toast-error').should('be.visible');
    cy.get('.toast-error').should('contain', 'OAuth configuration error');
  });

  it('should process OAuth callback correctly', () => {
    // Mock window.location.hash for OAuth callback
    cy.visit('/auth-callback.html', {
      onBeforeLoad(win) {
        // Simulate OAuth callback hash parameters
        win.location.hash = '#access_token=test-access-token&token_type=bearer&expires_in=3600&provider=google&refresh_token=test-refresh-token';
        
        // Setup stubs for Supabase
        win.ezEdit = win.ezEdit || {};
        win.ezEdit.supabase = {
          setSession: cy.stub().as('setSession').resolves({
            data: { user: { id: 'test-user-id', email: 'oauth@example.com' } },
            error: null
          }),
          getProfile: cy.stub().resolves({
            data: null,
            error: { message: 'Profile not found' }
          }),
          createProfile: cy.stub().as('createProfile').resolves({
            data: { id: 'new-profile-id' },
            error: null
          })
        };
        
        // Stub location.href for redirect check
        cy.stub(win.location, 'href').as('locationHref');
      }
    });
    
    // Check that setSession was called with the token
    cy.get('@setSession').should('be.calledWith', 'test-access-token');
    
    // Check that createProfile was called (since profile didn't exist)
    cy.get('@createProfile').should('be.called');
    
    // Check for success toast
    cy.get('.toast-success').should('be.visible');
    
    // Check that user is redirected to dashboard
    cy.get('@locationHref').should('eq', '/dashboard.html');
    
    // Check that auth data is stored in localStorage
    cy.window().then((win) => {
      const authData = JSON.parse(win.localStorage.getItem('ezEditAuth'));
      expect(authData).to.have.property('isAuthenticated', true);
      expect(authData).to.have.property('user');
    });
  });

  it('should handle OAuth callback errors', () => {
    // Mock window.location.hash for OAuth error callback
    cy.visit('/auth-callback.html', {
      onBeforeLoad(win) {
        // Simulate OAuth error callback hash parameters
        win.location.hash = '#error=access_denied&error_description=User%20denied%20access';
        
        // Stub location.href for redirect check
        cy.stub(win.location, 'href').as('locationHref');
      }
    });
    
    // Check for error toast
    cy.get('.toast-error').should('be.visible');
    cy.get('.toast-error').should('contain', 'User denied access');
    
    // Check that user is redirected to login page
    cy.get('@locationHref').should('eq', '/login.html');
  });

  it('should allow a user to log out', () => {
    // Setup authenticated user
    cy.window().then((win) => {
      // Set authenticated state in localStorage
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { id: 'test-user-id', email: 'user@example.com' }
      }));
      
      // Setup stub for Supabase signOut
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'user@example.com' }),
        getSites: cy.stub().resolves([]),
        signOut: cy.stub().as('signOut').resolves({ error: null })
      };
      
      // Stub location.href for redirect check
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Open user menu
    cy.get('.user-menu-toggle').click();
    
    // Click logout button
    cy.get('.logout-btn').click();
    
    // Check that signOut was called
    cy.get('@signOut').should('be.called');
    
    // Check that user is redirected to homepage
    cy.get('@locationHref').should('eq', '/');
    
    // Check that auth data is removed from localStorage
    cy.window().then((win) => {
      expect(win.localStorage.getItem('ezEditAuth')).to.be.null;
    });
  });

  it('should redirect unauthenticated users from protected pages to login', () => {
    // Setup unauthenticated user
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(false)
      };
      
      // Stub location.href for redirect check
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Try to visit dashboard
    cy.visit('/dashboard.html');
    
    // Check that user is redirected to login page
    cy.get('@locationHref').should('contain', '/login.html?redirect=/dashboard.html');
  });

  it('should maintain authentication state across page reloads', () => {
    // Setup authenticated user
    cy.window().then((win) => {
      // Set authenticated state in localStorage
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { id: 'test-user-id', email: 'user@example.com' }
      }));
      
      // Setup stub for Supabase
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'user@example.com' }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check that user info is displayed
    cy.get('.user-info').should('contain', 'user@example.com');
    
    // Reload page
    cy.reload();
    
    // Check that user is still authenticated
    cy.get('.user-info').should('contain', 'user@example.com');
  });

  it('should redirect to the originally requested page after login', () => {
    // First try to access protected page
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(false)
      };
      
      // Stub location.href for redirect check
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Try to visit dashboard
    cy.visit('/dashboard.html');
    
    // Check redirect to login with redirect parameter
    cy.get('@locationHref').should('contain', '/login.html?redirect=/dashboard.html');
    
    // Now simulate successful login from that page
    cy.visit('/login.html?redirect=/dashboard.html', {
      onBeforeLoad(win) {
        // Setup stub for Supabase signIn
        win.ezEdit = win.ezEdit || {};
        win.ezEdit.supabase = {
          signIn: cy.stub().as('signIn').resolves({
            data: { 
              user: { id: 'test-user-id', email: 'user@example.com' },
              session: { access_token: 'test-token' }
            },
            error: null
          }),
          getProfile: cy.stub().resolves({
            data: { id: 'test-profile-id', user_id: 'test-user-id' },
            error: null
          })
        };
        
        // Stub location.href for redirect check
        cy.stub(win.location, 'href').as('locationHref');
      }
    });
    
    // Fill in login form
    cy.get('input[name="email"]').type('user@example.com');
    cy.get('input[name="password"]').type('SecurePassword123!');
    
    // Submit form
    cy.get('form').submit();
    
    // Check that user is redirected to the original page
    cy.get('@locationHref').should('eq', '/dashboard.html');
  });
});
