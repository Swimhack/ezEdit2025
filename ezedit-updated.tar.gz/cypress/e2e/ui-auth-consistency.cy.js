/**
 * UI Consistency and Authentication Tests
 * Tests UI components consistency and login authentication functionality
 */

describe('UI Components Consistency', () => {
  beforeEach(() => {
    // Stub Supabase authentication to avoid actual API calls
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(false),
        signIn: cy.stub().resolves({ user: { email: 'test@example.com' } }),
        signInWithProvider: cy.stub().resolves(true)
      };
    });
  });

  it('should have consistent header across all pages', () => {
    // Check header on homepage
    cy.visit('/');
    cy.get('ez-header').should('exist');
    cy.get('.logo-icon').should('contain', 'Ez');
    cy.get('.logo-text').should('contain', 'Edit.co');
    
    // Check header on login page
    cy.visit('/login.html');
    cy.get('ez-header').should('exist');
    cy.get('.logo-icon').should('contain', 'Ez');
    cy.get('.logo-text').should('contain', 'Edit.co');
    
    // Check header on signup page
    cy.visit('/signup.html');
    cy.get('ez-header').should('exist');
    cy.get('.logo-icon').should('contain', 'Ez');
    cy.get('.logo-text').should('contain', 'Edit.co');
  });

  it('should have consistent footer across all pages', () => {
    // Check footer on homepage
    cy.visit('/');
    cy.get('ez-footer').should('exist');
    cy.get('.footer-content').should('exist');
    cy.get('.footer-bottom').should('contain', new Date().getFullYear());
    
    // Check footer on login page
    cy.visit('/login.html');
    cy.get('ez-footer').should('exist');
    cy.get('.footer-content').should('exist');
    cy.get('.footer-bottom').should('contain', new Date().getFullYear());
    
    // Check footer on signup page
    cy.visit('/signup.html');
    cy.get('ez-footer').should('exist');
    cy.get('.footer-content').should('exist');
    cy.get('.footer-bottom').should('contain', new Date().getFullYear());
  });

  it('should have consistent button styling across all pages', () => {
    // Check buttons on homepage
    cy.visit('/');
    cy.get('.btn').first().should('have.css', 'background-color');
    cy.get('.btn-outline').first().should('have.css', 'border-color');
    
    // Check buttons on login page
    cy.visit('/login.html');
    cy.get('.btn').first().should('have.css', 'background-color');
    cy.get('.btn-outline').first().should('have.css', 'border-color');
    
    // Check buttons on signup page
    cy.visit('/signup.html');
    cy.get('.btn').first().should('have.css', 'background-color');
    cy.get('.btn-outline').first().should('have.css', 'border-color');
  });

  it('should have consistent form styling across auth pages', () => {
    // Check form on login page
    cy.visit('/login.html');
    cy.get('.form-group').should('exist');
    cy.get('.form-control').should('have.css', 'border');
    
    // Check form on signup page
    cy.visit('/signup.html');
    cy.get('.form-group').should('exist');
    cy.get('.form-control').should('have.css', 'border');
  });

  it('should have consistent social login buttons on auth pages', () => {
    // Check social login buttons on login page
    cy.visit('/login.html');
    cy.get('.btn-google').should('exist');
    cy.get('.btn-github').should('exist');
    
    // Check social login buttons on signup page
    cy.visit('/signup.html');
    cy.get('.btn-google').should('exist');
    cy.get('.btn-github').should('exist');
  });

  it('should toggle dark mode consistently', () => {
    // Visit homepage
    cy.visit('/');
    
    // Body should not have dark-mode class initially
    cy.get('body').should('not.have.class', 'dark-mode');
    
    // Find and click theme toggle button
    cy.get('.theme-toggle').click();
    
    // Body should have dark-mode class after toggle
    cy.get('body').should('have.class', 'dark-mode');
    
    // Reload page to check if dark mode persists
    cy.reload();
    cy.get('body').should('have.class', 'dark-mode');
    
    // Visit another page to check if dark mode persists
    cy.visit('/login.html');
    cy.get('body').should('have.class', 'dark-mode');
  });
});

describe('Authentication Functionality', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
    
    // Visit login page
    cy.visit('/login.html');
  });

  it('should show login form with email and password fields', () => {
    cy.get('#login-form').should('exist');
    cy.get('#email').should('exist');
    cy.get('#password').should('exist');
    cy.get('button[type="submit"]').should('exist');
  });

  it('should show validation errors for empty fields', () => {
    cy.get('button[type="submit"]').click();
    cy.get('#email:invalid').should('exist');
    cy.get('#password:invalid').should('exist');
  });

  it('should show validation error for invalid email format', () => {
    cy.get('#email').type('invalid-email');
    cy.get('button[type="submit"]').click();
    cy.get('#email:invalid').should('exist');
  });

  it('should show error message for incorrect credentials', () => {
    // Stub the signIn method to reject with an error
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signIn: cy.stub().rejects(new Error('Invalid login credentials')),
        isAuthenticated: cy.stub().returns(false)
      };
    });
    
    cy.get('#email').type('test@example.com');
    cy.get('#password').type('wrongpassword');
    cy.get('button[type="submit"]').click();
    
    cy.get('#login-error').should('be.visible');
    cy.get('#login-error').should('contain', 'Invalid login credentials');
  });

  it('should redirect to dashboard on successful login', () => {
    // Stub the signIn method to resolve successfully
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signIn: cy.stub().resolves({ user: { email: 'test@example.com' } }),
        isAuthenticated: cy.stub().returns(true)
      };
      
      // Stub window.location.href to verify redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    cy.get('#email').type('test@example.com');
    cy.get('#password').type('correctpassword');
    cy.get('button[type="submit"]').click();
    
    // Check that redirect was attempted
    cy.get('@locationHref').should('contain', '/dashboard.html');
  });

  it('should handle Google OAuth login button click', () => {
    // Stub the signInWithProvider method
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signInWithProvider: cy.stub().as('signInWithProvider')
      };
    });
    
    // Click the Google login button
    cy.get('.btn-google').click();
    
    // Verify the signInWithProvider method was called with 'google'
    cy.get('@signInWithProvider').should('be.calledWith', 'google');
  });

  it('should handle GitHub OAuth login button click', () => {
    // Stub the signInWithProvider method
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signInWithProvider: cy.stub().as('signInWithProvider')
      };
    });
    
    // Click the GitHub login button
    cy.get('.btn-github').click();
    
    // Verify the signInWithProvider method was called with 'github'
    cy.get('@signInWithProvider').should('be.calledWith', 'github');
  });
});

describe('Dashboard Authentication Guard', () => {
  it('should redirect unauthenticated users from dashboard to login', () => {
    // Stub authentication to return false (not authenticated)
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(false)
      };
      
      // Stub window.location.href to verify redirect
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Try to visit dashboard
    cy.visit('/dashboard.html');
    
    // Check that redirect to login was attempted
    cy.get('@locationHref').should('contain', '/login.html');
  });

  it('should allow authenticated users to access dashboard', () => {
    // Stub authentication to return true (authenticated)
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' })
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Verify dashboard content is visible
    cy.get('.dashboard-header').should('exist');
    cy.get('#add-site-btn').should('exist');
  });
});
