/**
 * Site Management Tests
 * Tests the functionality for adding, editing, and deleting FTP sites
 */

describe('Site Management', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
    
    // Setup authenticated user
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { id: 'test-user-id', email: 'user@example.com' }
      }));
      
      // Setup stub for Supabase
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'user@example.com', id: 'test-user-id' }),
        getSites: cy.stub().as('getSites').resolves([
          {
            id: 'site-1',
            name: 'Test Site 1',
            host: 'ftp.example.com',
            port: 21,
            username: 'ftpuser',
            passive: true,
            created_at: new Date().toISOString()
          }
        ])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
  });

  it('should display existing sites on dashboard', () => {
    // Check that getSites was called
    cy.get('@getSites').should('be.called');
    
    // Check that site card is displayed
    cy.get('.site-card').should('have.length', 1);
    cy.get('.site-card').should('contain', 'Test Site 1');
    cy.get('.site-card').should('contain', 'ftp.example.com');
  });

  it('should open add site modal when add site button is clicked', () => {
    // Click add site button
    cy.get('.add-site-btn').click();
    
    // Check that modal is displayed
    cy.get('.site-modal').should('be.visible');
    cy.get('.site-modal-title').should('contain', 'Add Site');
    
    // Check form fields
    cy.get('.site-modal input[name="name"]').should('be.visible');
    cy.get('.site-modal input[name="host"]').should('be.visible');
    cy.get('.site-modal input[name="port"]').should('be.visible');
    cy.get('.site-modal input[name="username"]').should('be.visible');
    cy.get('.site-modal input[name="password"]').should('be.visible');
    cy.get('.site-modal input[name="passive"]').should('be.visible');
  });

  it('should add a new site', () => {
    // Setup stub for addSite
    cy.window().then((win) => {
      win.ezEdit.supabase.addSite = cy.stub().as('addSite').resolves({
        data: {
          id: 'new-site-id',
          name: 'New Test Site',
          host: 'ftp.test.com',
          port: 21,
          username: 'testuser',
          passive: true,
          created_at: new Date().toISOString()
        },
        error: null
      });
    });
    
    // Click add site button
    cy.get('.add-site-btn').click();
    
    // Fill form
    cy.get('.site-modal input[name="name"]').type('New Test Site');
    cy.get('.site-modal input[name="host"]').type('ftp.test.com');
    cy.get('.site-modal input[name="port"]').clear().type('21');
    cy.get('.site-modal input[name="username"]').type('testuser');
    cy.get('.site-modal input[name="password"]').type('password123');
    cy.get('.site-modal input[name="passive"]').check();
    
    // Submit form
    cy.get('.site-modal .save-btn').click();
    
    // Check that addSite was called with correct parameters
    cy.get('@addSite').should('be.calledWith', {
      name: 'New Test Site',
      host: 'ftp.test.com',
      port: 21,
      username: 'testuser',
      password: 'password123',
      passive: true,
      user_id: 'test-user-id'
    });
    
    // Check for success toast
    cy.get('.toast-success').should('be.visible');
    cy.get('.toast-success').should('contain', 'Site added');
    
    // Check that modal is closed
    cy.get('.site-modal').should('not.be.visible');
  });

  it('should show validation errors when adding a site with invalid data', () => {
    // Click add site button
    cy.get('.add-site-btn').click();
    
    // Submit empty form
    cy.get('.site-modal .save-btn').click();
    
    // Check for validation errors
    cy.get('.site-modal .error-message').should('be.visible');
    
    // Fill with invalid host
    cy.get('.site-modal input[name="name"]').type('Invalid Site');
    cy.get('.site-modal input[name="host"]').type('invalid host');
    cy.get('.site-modal .save-btn').click();
    
    // Check for host validation error
    cy.get('.site-modal .error-message').should('contain', 'valid hostname');
    
    // Fill with invalid port
    cy.get('.site-modal input[name="host"]').clear().type('valid.host.com');
    cy.get('.site-modal input[name="port"]').clear().type('invalid');
    cy.get('.site-modal .save-btn').click();
    
    // Check for port validation error
    cy.get('.site-modal .error-message').should('contain', 'valid port');
  });

  it('should handle errors when adding a site', () => {
    // Setup stub for addSite with error
    cy.window().then((win) => {
      win.ezEdit.supabase.addSite = cy.stub().as('addSite').resolves({
        data: null,
        error: { message: 'Failed to add site' }
      });
    });
    
    // Click add site button
    cy.get('.add-site-btn').click();
    
    // Fill form
    cy.get('.site-modal input[name="name"]').type('Error Site');
    cy.get('.site-modal input[name="host"]').type('ftp.error.com');
    cy.get('.site-modal input[name="port"]').clear().type('21');
    cy.get('.site-modal input[name="username"]').type('erroruser');
    cy.get('.site-modal input[name="password"]').type('password123');
    
    // Submit form
    cy.get('.site-modal .save-btn').click();
    
    // Check for error toast
    cy.get('.toast-error').should('be.visible');
    cy.get('.toast-error').should('contain', 'Failed to add site');
    
    // Check that modal is still open
    cy.get('.site-modal').should('be.visible');
  });

  it('should edit an existing site', () => {
    // Setup stub for updateSite
    cy.window().then((win) => {
      win.ezEdit.supabase.updateSite = cy.stub().as('updateSite').resolves({
        data: {
          id: 'site-1',
          name: 'Updated Site',
          host: 'ftp.updated.com',
          port: 22,
          username: 'updateduser',
          passive: false,
          created_at: new Date().toISOString()
        },
        error: null
      });
    });
    
    // Click edit button on site card
    cy.get('.site-card .edit-btn').click();
    
    // Check that modal is displayed with site data
    cy.get('.site-modal').should('be.visible');
    cy.get('.site-modal-title').should('contain', 'Edit Site');
    cy.get('.site-modal input[name="name"]').should('have.value', 'Test Site 1');
    cy.get('.site-modal input[name="host"]').should('have.value', 'ftp.example.com');
    
    // Update form
    cy.get('.site-modal input[name="name"]').clear().type('Updated Site');
    cy.get('.site-modal input[name="host"]').clear().type('ftp.updated.com');
    cy.get('.site-modal input[name="port"]').clear().type('22');
    cy.get('.site-modal input[name="username"]').clear().type('updateduser');
    cy.get('.site-modal input[name="password"]').type('newpassword');
    cy.get('.site-modal input[name="passive"]').uncheck();
    
    // Submit form
    cy.get('.site-modal .save-btn').click();
    
    // Check that updateSite was called with correct parameters
    cy.get('@updateSite').should('be.calledWith', {
      id: 'site-1',
      name: 'Updated Site',
      host: 'ftp.updated.com',
      port: 22,
      username: 'updateduser',
      password: 'newpassword',
      passive: false
    });
    
    // Check for success toast
    cy.get('.toast-success').should('be.visible');
    cy.get('.toast-success').should('contain', 'Site updated');
    
    // Check that modal is closed
    cy.get('.site-modal').should('not.be.visible');
  });

  it('should delete a site', () => {
    // Setup stub for deleteSite
    cy.window().then((win) => {
      win.ezEdit.supabase.deleteSite = cy.stub().as('deleteSite').resolves({
        data: { id: 'site-1' },
        error: null
      });
    });
    
    // Click delete button on site card
    cy.get('.site-card .delete-btn').click();
    
    // Check that confirmation dialog is displayed
    cy.get('.confirm-dialog').should('be.visible');
    cy.get('.confirm-dialog').should('contain', 'Are you sure');
    
    // Confirm deletion
    cy.get('.confirm-dialog .confirm-btn').click();
    
    // Check that deleteSite was called with correct parameters
    cy.get('@deleteSite').should('be.calledWith', 'site-1');
    
    // Check for success toast
    cy.get('.toast-success').should('be.visible');
    cy.get('.toast-success').should('contain', 'Site deleted');
    
    // Check that site card is removed
    cy.get('.site-card').should('not.exist');
  });

  it('should cancel site deletion when cancel button is clicked', () => {
    // Setup stub for deleteSite
    cy.window().then((win) => {
      win.ezEdit.supabase.deleteSite = cy.stub().as('deleteSite');
    });
    
    // Click delete button on site card
    cy.get('.site-card .delete-btn').click();
    
    // Check that confirmation dialog is displayed
    cy.get('.confirm-dialog').should('be.visible');
    
    // Cancel deletion
    cy.get('.confirm-dialog .cancel-btn').click();
    
    // Check that deleteSite was not called
    cy.get('@deleteSite').should('not.be.called');
    
    // Check that confirmation dialog is closed
    cy.get('.confirm-dialog').should('not.be.visible');
    
    // Check that site card still exists
    cy.get('.site-card').should('exist');
  });
});
