/**
 * Code Editor Tests
 * Tests the Monaco editor integration, diff view, and code editing functionality
 */

describe('Code Editor', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
    
    // Setup authenticated user with Pro plan
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'test-user-id', 
          email: 'user@example.com',
          subscription: {
            plan: 'pro',
            status: 'active',
            expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
          }
        }
      }));
      
      // Setup stub for Supabase and FTP service
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ 
          email: 'user@example.com', 
          id: 'test-user-id',
          subscription: {
            plan: 'pro',
            status: 'active'
          }
        }),
        getSites: cy.stub().resolves([
          {
            id: 'site-1',
            name: 'Test Site',
            host: 'ftp.example.com',
            port: 21,
            username: 'ftpuser',
            passive: true,
            created_at: new Date().toISOString()
          }
        ])
      };
      
      win.ezEdit.ftpService = {
        connect: cy.stub().as('ftpConnect').resolves({ success: true }),
        listFiles: cy.stub().as('listFiles').resolves({
          success: true,
          files: [
            { name: 'index.html', type: 'file', size: 1024 },
            { name: 'styles', type: 'directory' },
            { name: 'scripts', type: 'directory' }
          ]
        }),
        getFile: cy.stub().as('getFile').resolves({
          success: true,
          content: '<!DOCTYPE html>\n<html>\n<head>\n  <title>Test Page</title>\n</head>\n<body>\n  <h1>Hello World</h1>\n</body>\n</html>'
        }),
        saveFile: cy.stub().as('saveFile').resolves({ success: true })
      };
      
      // Stub Monaco editor
      win.monaco = {
        editor: {
          create: cy.stub().as('createEditor').returns({
            setValue: cy.stub(),
            getValue: cy.stub().returns('<!DOCTYPE html>\n<html>\n<head>\n  <title>Test Page</title>\n</head>\n<body>\n  <h1>Hello World - Edited</h1>\n</body>\n</html>'),
            getModel: cy.stub().returns({
              setValue: cy.stub(),
              getValue: cy.stub()
            }),
            layout: cy.stub(),
            dispose: cy.stub()
          }),
          createDiffEditor: cy.stub().as('createDiffEditor').returns({
            setModel: cy.stub(),
            getOriginalEditor: cy.stub().returns({
              setValue: cy.stub(),
              getValue: cy.stub(),
              getModel: cy.stub().returns({
                setValue: cy.stub(),
                getValue: cy.stub()
              })
            }),
            getModifiedEditor: cy.stub().returns({
              setValue: cy.stub(),
              getValue: cy.stub().returns('<!DOCTYPE html>\n<html>\n<head>\n  <title>Test Page</title>\n</head>\n<body>\n  <h1>Hello World - Edited</h1>\n</body>\n</html>'),
              getModel: cy.stub().returns({
                setValue: cy.stub(),
                getValue: cy.stub()
              })
            }),
            layout: cy.stub(),
            dispose: cy.stub()
          })
        },
        Uri: {
          parse: cy.stub().returns({})
        },
        editor: {
          createModel: cy.stub().returns({})
        }
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
  });

  it('should navigate to editor when clicking on a site', () => {
    // Click on site card
    cy.get('.site-card').click();
    
    // Check that FTP connect was called
    cy.get('@ftpConnect').should('be.called');
    
    // Check that we navigated to editor page
    cy.url().should('include', '/editor.html');
    
    // Check that site name is displayed
    cy.get('.site-name').should('contain', 'Test Site');
  });

  it('should display file explorer with FTP directory contents', () => {
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Check that listFiles was called
    cy.get('@listFiles').should('be.called');
    
    // Check that file explorer is displayed
    cy.get('.file-explorer').should('be.visible');
    
    // Check that files are displayed
    cy.get('.file-item').should('have.length', 3);
    cy.get('.file-item').eq(0).should('contain', 'index.html');
    cy.get('.file-item').eq(1).should('contain', 'styles');
    cy.get('.file-item').eq(2).should('contain', 'scripts');
  });

  it('should open a file in the editor when clicked', () => {
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Click on a file
    cy.get('.file-item').contains('index.html').click();
    
    // Check that getFile was called
    cy.get('@getFile').should('be.called');
    
    // Check that editor is displayed
    cy.get('.monaco-editor').should('be.visible');
    
    // Check that createDiffEditor was called
    cy.get('@createDiffEditor').should('be.called');
  });

  it('should show diff view with original and modified content', () => {
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Click on a file
    cy.get('.file-item').contains('index.html').click();
    
    // Check that diff view is displayed
    cy.get('.diff-view').should('be.visible');
    cy.get('.original-editor').should('be.visible');
    cy.get('.modified-editor').should('be.visible');
  });

  it('should enable save button when content is modified', () => {
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Click on a file
    cy.get('.file-item').contains('index.html').click();
    
    // Initially save button should be disabled
    cy.get('.save-btn').should('be.disabled');
    
    // Simulate content change
    cy.window().then((win) => {
      // Trigger change event
      const changeEvent = new Event('change');
      win.document.querySelector('.monaco-editor').dispatchEvent(changeEvent);
    });
    
    // Save button should be enabled
    cy.get('.save-btn').should('not.be.disabled');
  });

  it('should save modified content when save button is clicked', () => {
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Click on a file
    cy.get('.file-item').contains('index.html').click();
    
    // Simulate content change
    cy.window().then((win) => {
      // Trigger change event
      const changeEvent = new Event('change');
      win.document.querySelector('.monaco-editor').dispatchEvent(changeEvent);
    });
    
    // Click save button
    cy.get('.save-btn').click();
    
    // Check that saveFile was called with correct content
    cy.get('@saveFile').should('be.called');
    
    // Check for success toast
    cy.get('.toast-success').should('be.visible');
    cy.get('.toast-success').should('contain', 'File saved');
  });

  it('should show preview of HTML files', () => {
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Click on a file
    cy.get('.file-item').contains('index.html').click();
    
    // Click preview button
    cy.get('.preview-btn').click();
    
    // Check that preview pane is displayed
    cy.get('.preview-pane').should('be.visible');
    
    // Check that iframe is loaded
    cy.get('.preview-iframe').should('be.visible');
  });

  it('should update preview when content is saved', () => {
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Click on a file
    cy.get('.file-item').contains('index.html').click();
    
    // Show preview
    cy.get('.preview-btn').click();
    
    // Simulate content change
    cy.window().then((win) => {
      // Trigger change event
      const changeEvent = new Event('change');
      win.document.querySelector('.monaco-editor').dispatchEvent(changeEvent);
    });
    
    // Save changes
    cy.get('.save-btn').click();
    
    // Check that preview is refreshed
    cy.get('.preview-iframe').should('have.attr', 'src').and('include', 'timestamp=');
  });

  it('should show AI assistant panel when requested', () => {
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Click on a file
    cy.get('.file-item').contains('index.html').click();
    
    // Click AI assistant button
    cy.get('.ai-assist-btn').click();
    
    // Check that AI panel is displayed
    cy.get('.ai-panel').should('be.visible');
    
    // Check that chat input is displayed
    cy.get('.ai-chat-input').should('be.visible');
  });

  it('should apply AI suggested changes when approved', () => {
    // Setup stub for AI service
    cy.window().then((win) => {
      win.ezEdit.aiService = {
        generateSuggestion: cy.stub().as('generateSuggestion').resolves({
          success: true,
          suggestion: '<!DOCTYPE html>\n<html>\n<head>\n  <title>AI Improved Page</title>\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n</head>\n<body>\n  <h1>Hello World - AI Enhanced</h1>\n</body>\n</html>',
          explanation: 'Added viewport meta tag and improved title'
        })
      };
    });
    
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Click on a file
    cy.get('.file-item').contains('index.html').click();
    
    // Open AI panel
    cy.get('.ai-assist-btn').click();
    
    // Type a prompt
    cy.get('.ai-chat-input').type('Add a viewport meta tag{enter}');
    
    // Check that generateSuggestion was called
    cy.get('@generateSuggestion').should('be.called');
    
    // Check that suggestion is displayed
    cy.get('.ai-suggestion').should('be.visible');
    
    // Click apply button
    cy.get('.apply-suggestion-btn').click();
    
    // Check that editor content was updated
    cy.window().then((win) => {
      expect(win.ezEdit.editor.getModifiedEditor().getValue()).to.include('viewport');
    });
  });

  it('should block save functionality for free plan users', () => {
    // Change user to free plan
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'test-user-id', 
          email: 'user@example.com',
          subscription: {
            plan: 'free',
            status: 'active',
            expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
          }
        }
      }));
      
      win.ezEdit.supabase.getUser = cy.stub().returns({ 
        email: 'user@example.com', 
        id: 'test-user-id',
        subscription: {
          plan: 'free',
          status: 'active'
        }
      });
    });
    
    // Reload page
    cy.reload();
    
    // Navigate to editor
    cy.get('.site-card').click();
    
    // Click on a file
    cy.get('.file-item').contains('index.html').click();
    
    // Simulate content change
    cy.window().then((win) => {
      // Trigger change event
      const changeEvent = new Event('change');
      win.document.querySelector('.monaco-editor').dispatchEvent(changeEvent);
    });
    
    // Save button should be disabled or show upgrade tooltip
    cy.get('.save-btn').should('have.class', 'upgrade-required');
    
    // Click save button
    cy.get('.save-btn').click();
    
    // Check for upgrade toast or modal
    cy.get('.upgrade-modal').should('be.visible');
    cy.get('.upgrade-modal').should('contain', 'Pro plan');
  });
});
