/**
 * Subscription and Payment Tests
 * Tests the Stripe integration, subscription plans, and payment flows
 */

describe('Subscription and Payment', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
    
    // Setup authenticated user with free trial
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'test-user-id', 
          email: 'user@example.com',
          subscription: {
            plan: 'free',
            status: 'active',
            trial_end: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
          }
        }
      }));
      
      // Setup stub for Supabase
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ 
          email: 'user@example.com', 
          id: 'test-user-id',
          subscription: {
            plan: 'free',
            status: 'active',
            trial_end: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
          }
        }),
        getSites: cy.stub().resolves([
          {
            id: 'site-1',
            name: 'Test Site',
            host: 'ftp.example.com',
            port: 21,
            username: 'ftpuser',
            passive: true,
            created_at: new Date().toISOString()
          }
        ]),
        updateSubscription: cy.stub().as('updateSubscription').resolves({
          data: {
            id: 'test-user-id',
            subscription: {
              plan: 'pro',
              status: 'active',
              current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
            }
          },
          error: null
        })
      };
      
      // Stub Stripe
      win.Stripe = cy.stub().returns({
        redirectToCheckout: cy.stub().as('redirectToCheckout').resolves({ error: null })
      });
      
      // Set environment variables
      win.env = {
        STRIPE_PUBLIC_KEY: 'pk_test_123456',
        STRIPE_PRICE_PRO: 'price_subPro_$100',
        STRIPE_PRICE_SITE: 'price_oneTimeSite_$500'
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
  });

  it('should display free trial status on dashboard', () => {
    // Check that trial status is displayed
    cy.get('.trial-status').should('be.visible');
    cy.get('.trial-status').should('contain', 'Free Trial');
    cy.get('.trial-status').should('contain', '7 days');
    
    // Check that upgrade button is displayed
    cy.get('.upgrade-btn').should('be.visible');
  });

  it('should display subscription plans when upgrade button is clicked', () => {
    // Click upgrade button
    cy.get('.upgrade-btn').click();
    
    // Check that plans modal is displayed
    cy.get('.plans-modal').should('be.visible');
    
    // Check that plans are displayed
    cy.get('.plan-card').should('have.length', 2);
    cy.get('.plan-card').eq(0).should('contain', 'Free');
    cy.get('.plan-card').eq(1).should('contain', 'Pro');
    cy.get('.plan-card').eq(1).should('contain', '$50/mo');
  });

  it('should initiate Stripe checkout when selecting Pro plan', () => {
    // Click upgrade button
    cy.get('.upgrade-btn').click();
    
    // Click on Pro plan
    cy.get('.plan-card').contains('Pro').parent().find('.select-plan-btn').click();
    
    // Check that Stripe was initialized with correct key
    cy.window().then((win) => {
      expect(win.Stripe).to.be.calledWith('pk_test_123456');
    });
    
    // Check that redirectToCheckout was called with correct parameters
    cy.get('@redirectToCheckout').should('be.calledWith', {
      lineItems: [{ price: 'price_subPro_$100', quantity: 1 }],
      mode: 'subscription',
      successUrl: Cypress.sinon.match.string,
      cancelUrl: Cypress.sinon.match.string,
      clientReferenceId: 'test-user-id'
    });
  });

  it('should handle Stripe checkout errors', () => {
    // Setup Stripe with error
    cy.window().then((win) => {
      win.Stripe = cy.stub().returns({
        redirectToCheckout: cy.stub().as('redirectToCheckout').resolves({ 
          error: { message: 'Invalid payment method' } 
        })
      });
    });
    
    // Click upgrade button
    cy.get('.upgrade-btn').click();
    
    // Click on Pro plan
    cy.get('.plan-card').contains('Pro').parent().find('.select-plan-btn').click();
    
    // Check for error toast
    cy.get('.toast-error').should('be.visible');
    cy.get('.toast-error').should('contain', 'Invalid payment method');
  });

  it('should process successful subscription webhook', () => {
    // Simulate webhook processing
    cy.window().then((win) => {
      // Create mock event
      const event = {
        type: 'checkout.session.completed',
        data: {
          object: {
            client_reference_id: 'test-user-id',
            subscription: 'sub_123456',
            customer: 'cus_123456',
            mode: 'subscription'
          }
        }
      };
      
      // Call webhook handler
      win.ezEdit.webhookHandler = {
        processStripeEvent: cy.stub().as('processStripeEvent').callsFake(async (evt) => {
          // Update user subscription
          await win.ezEdit.supabase.updateSubscription({
            userId: evt.data.object.client_reference_id,
            subscription: {
              id: evt.data.object.subscription,
              customer: evt.data.object.customer,
              plan: 'pro',
              status: 'active',
              current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
            }
          });
          
          return { success: true };
        })
      };
      
      // Process event
      win.ezEdit.webhookHandler.processStripeEvent(event);
    });
    
    // Check that updateSubscription was called
    cy.get('@updateSubscription').should('be.called');
    
    // Reload page to see changes
    cy.reload();
    
    // Check that subscription status is updated
    cy.get('.subscription-status').should('contain', 'Pro');
    cy.get('.subscription-status').should('not.contain', 'Free Trial');
  });

  it('should allow one-time site purchase', () => {
    // Click add site button
    cy.get('.add-site-btn').click();
    
    // Check that site modal is displayed
    cy.get('.site-modal').should('be.visible');
    
    // Fill form
    cy.get('.site-modal input[name="name"]').type('Purchased Site');
    cy.get('.site-modal input[name="host"]').type('ftp.purchased.com');
    cy.get('.site-modal input[name="port"]').clear().type('21');
    cy.get('.site-modal input[name="username"]').type('purchaseuser');
    cy.get('.site-modal input[name="password"]').type('password123');
    
    // Submit form
    cy.get('.site-modal .save-btn').click();
    
    // Check that payment modal is displayed for free users
    cy.get('.payment-modal').should('be.visible');
    cy.get('.payment-modal').should('contain', 'Purchase Site');
    cy.get('.payment-modal').should('contain', '$50');
    
    // Click purchase button
    cy.get('.payment-modal .purchase-btn').click();
    
    // Check that Stripe was initialized with correct key
    cy.window().then((win) => {
      expect(win.Stripe).to.be.calledWith('pk_test_123456');
    });
    
    // Check that redirectToCheckout was called with correct parameters
    cy.get('@redirectToCheckout').should('be.calledWith', {
      lineItems: [{ price: 'price_oneTimeSite_$500', quantity: 1 }],
      mode: 'payment',
      successUrl: Cypress.sinon.match.string,
      cancelUrl: Cypress.sinon.match.string,
      clientReferenceId: 'test-user-id'
    });
  });

  it('should show different UI elements based on subscription status', () => {
    // Check free trial UI elements
    cy.get('.trial-status').should('be.visible');
    cy.get('.upgrade-btn').should('be.visible');
    cy.get('.feature-limited-badge').should('be.visible');
    
    // Change user to pro plan
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'test-user-id', 
          email: 'user@example.com',
          subscription: {
            plan: 'pro',
            status: 'active',
            current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
          }
        }
      }));
      
      win.ezEdit.supabase.getUser = cy.stub().returns({ 
        email: 'user@example.com', 
        id: 'test-user-id',
        subscription: {
          plan: 'pro',
          status: 'active',
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        }
      });
    });
    
    // Reload page
    cy.reload();
    
    // Check pro plan UI elements
    cy.get('.subscription-status').should('contain', 'Pro');
    cy.get('.trial-status').should('not.exist');
    cy.get('.upgrade-btn').should('not.exist');
    cy.get('.feature-limited-badge').should('not.exist');
    cy.get('.pro-badge').should('be.visible');
  });

  it('should handle subscription cancellation', () => {
    // Setup pro user with cancel option
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'test-user-id', 
          email: 'user@example.com',
          subscription: {
            plan: 'pro',
            status: 'active',
            current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
          }
        }
      }));
      
      win.ezEdit.supabase.getUser = cy.stub().returns({ 
        email: 'user@example.com', 
        id: 'test-user-id',
        subscription: {
          plan: 'pro',
          status: 'active',
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        }
      });
      
      win.ezEdit.supabase.cancelSubscription = cy.stub().as('cancelSubscription').resolves({
        data: {
          id: 'test-user-id',
          subscription: {
            plan: 'pro',
            status: 'canceled',
            current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
          }
        },
        error: null
      });
    });
    
    // Reload page
    cy.reload();
    
    // Open account settings
    cy.get('.user-menu-toggle').click();
    cy.get('.account-settings-link').click();
    
    // Check that account settings modal is displayed
    cy.get('.account-modal').should('be.visible');
    
    // Click cancel subscription button
    cy.get('.cancel-subscription-btn').click();
    
    // Check that confirmation dialog is displayed
    cy.get('.confirm-dialog').should('be.visible');
    cy.get('.confirm-dialog').should('contain', 'cancel your subscription');
    
    // Confirm cancellation
    cy.get('.confirm-dialog .confirm-btn').click();
    
    // Check that cancelSubscription was called
    cy.get('@cancelSubscription').should('be.called');
    
    // Check for success toast
    cy.get('.toast-success').should('be.visible');
    cy.get('.toast-success').should('contain', 'Subscription canceled');
    
    // Check that subscription status is updated
    cy.get('.subscription-status').should('contain', 'Canceled');
    cy.get('.subscription-end-date').should('be.visible');
  });

  it('should handle payment method updates', () => {
    // Setup pro user
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'test-user-id', 
          email: 'user@example.com',
          subscription: {
            plan: 'pro',
            status: 'active',
            current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
          }
        }
      }));
      
      win.ezEdit.supabase.getUser = cy.stub().returns({ 
        email: 'user@example.com', 
        id: 'test-user-id',
        subscription: {
          plan: 'pro',
          status: 'active',
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        }
      });
      
      win.ezEdit.supabase.createPaymentUpdateSession = cy.stub().as('createPaymentUpdateSession').resolves({
        data: {
          url: 'https://stripe.com/update-payment-method'
        },
        error: null
      });
      
      // Stub window.location.href
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Reload page
    cy.reload();
    
    // Open account settings
    cy.get('.user-menu-toggle').click();
    cy.get('.account-settings-link').click();
    
    // Click update payment method button
    cy.get('.update-payment-btn').click();
    
    // Check that createPaymentUpdateSession was called
    cy.get('@createPaymentUpdateSession').should('be.called');
    
    // Check that user is redirected to Stripe
    cy.get('@locationHref').should('eq', 'https://stripe.com/update-payment-method');
  });
});
