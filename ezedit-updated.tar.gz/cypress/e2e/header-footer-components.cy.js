/**
 * Header and Footer Components Tests
 * Tests the header and footer web components across all pages to ensure consistent behavior
 */

describe('Header Component', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
  });

  it('should render consistently on homepage', () => {
    // Visit homepage
    cy.visit('/');
    
    // Check header exists
    cy.get('ez-header').should('exist');
    
    // Check logo
    cy.get('ez-header .logo-icon').should('contain', 'Ez');
    cy.get('ez-header .logo-text').should('contain', 'Edit.co');
    
    // Check navigation links
    cy.get('ez-header .nav-links').should('exist');
    cy.get('ez-header .nav-links a').should('have.length.at.least', 3);
    
    // Check theme toggle
    cy.get('ez-header .theme-toggle').should('exist');
  });

  it('should render consistently on login page', () => {
    // Visit login page
    cy.visit('/login.html');
    
    // Check header exists
    cy.get('ez-header').should('exist');
    
    // Check logo
    cy.get('ez-header .logo-icon').should('contain', 'Ez');
    cy.get('ez-header .logo-text').should('contain', 'Edit.co');
    
    // Check navigation links
    cy.get('ez-header .nav-links').should('exist');
    
    // Check theme toggle
    cy.get('ez-header .theme-toggle').should('exist');
  });

  it('should render consistently on signup page', () => {
    // Visit signup page
    cy.visit('/signup.html');
    
    // Check header exists
    cy.get('ez-header').should('exist');
    
    // Check logo
    cy.get('ez-header .logo-icon').should('contain', 'Ez');
    cy.get('ez-header .logo-text').should('contain', 'Edit.co');
    
    // Check navigation links
    cy.get('ez-header .nav-links').should('exist');
    
    // Check theme toggle
    cy.get('ez-header .theme-toggle').should('exist');
  });

  it('should render consistently on dashboard page', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check header exists
    cy.get('ez-header').should('exist');
    
    // Check logo
    cy.get('ez-header .logo-icon').should('contain', 'Ez');
    cy.get('ez-header .logo-text').should('contain', 'Edit.co');
    
    // Check navigation links
    cy.get('ez-header .nav-links').should('exist');
    
    // Check user menu
    cy.get('ez-header .user-menu').should('exist');
    cy.get('ez-header .user-info').should('contain', 'test@example.com');
    
    // Check theme toggle
    cy.get('ez-header .theme-toggle').should('exist');
  });

  it('should show different navigation links when logged in', () => {
    // Visit homepage without authentication
    cy.visit('/');
    
    // Check for login/signup links
    cy.get('ez-header .nav-links').should('contain', 'Login');
    cy.get('ez-header .nav-links').should('contain', 'Sign Up');
    
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' })
      };
    });
    
    // Reload page
    cy.reload();
    
    // Check for dashboard link instead of login/signup
    cy.get('ez-header .nav-links').should('contain', 'Dashboard');
    cy.get('ez-header .nav-links').should('not.contain', 'Login');
    cy.get('ez-header .nav-links').should('not.contain', 'Sign Up');
  });

  it('should navigate to correct pages when links are clicked', () => {
    // Visit homepage
    cy.visit('/');
    
    // Stub window.location.href
    cy.window().then((win) => {
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Click on login link
    cy.get('ez-header .nav-links a').contains('Login').click();
    
    // Check that it would navigate to login page
    cy.get('@locationHref').should('contain', '/login.html');
    
    // Reset stub
    cy.window().then((win) => {
      win.location.href.restore();
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Click on signup link
    cy.get('ez-header .nav-links a').contains('Sign Up').click();
    
    // Check that it would navigate to signup page
    cy.get('@locationHref').should('contain', '/signup.html');
  });

  it('should handle user menu toggle', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // User dropdown should be hidden initially
    cy.get('ez-header .user-dropdown').should('not.be.visible');
    
    // Click user menu toggle
    cy.get('ez-header .user-menu-toggle').click();
    
    // User dropdown should be visible
    cy.get('ez-header .user-dropdown').should('be.visible');
    
    // Click outside the dropdown
    cy.get('body').click(0, 0);
    
    // User dropdown should be hidden again
    cy.get('ez-header .user-dropdown').should('not.be.visible');
  });

  it('should handle logout', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([]),
        signOut: cy.stub().as('signOut').resolves(true)
      };
      
      // Stub location.href
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Open user menu
    cy.get('ez-header .user-menu-toggle').click();
    
    // Click logout button
    cy.get('ez-header .logout-btn').click();
    
    // Check that signOut was called
    cy.get('@signOut').should('be.called');
    
    // Check redirect to homepage
    cy.get('@locationHref').should('eq', '/');
  });

  it('should have consistent styling in light mode', () => {
    // Ensure light mode
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'false');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Get header background color
    cy.get('ez-header').invoke('css', 'background-color').then((headerColor) => {
      // Visit login page
      cy.visit('/login.html');
      
      // Check that header has the same background color
      cy.get('ez-header').should('have.css', 'background-color', headerColor);
    });
  });

  it('should have consistent styling in dark mode', () => {
    // Enable dark mode
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'true');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Get header background color
    cy.get('ez-header').invoke('css', 'background-color').then((headerColor) => {
      // Visit login page
      cy.visit('/login.html');
      
      // Check that header has the same background color
      cy.get('ez-header').should('have.css', 'background-color', headerColor);
    });
  });
});

describe('Footer Component', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
  });

  it('should render consistently on homepage', () => {
    // Visit homepage
    cy.visit('/');
    
    // Check footer exists
    cy.get('ez-footer').should('exist');
    
    // Check footer content
    cy.get('ez-footer .footer-content').should('exist');
    cy.get('ez-footer .footer-bottom').should('exist');
    
    // Check copyright year
    cy.get('ez-footer .footer-bottom').should('contain', new Date().getFullYear());
  });

  it('should render consistently on login page', () => {
    // Visit login page
    cy.visit('/login.html');
    
    // Check footer exists
    cy.get('ez-footer').should('exist');
    
    // Check footer content
    cy.get('ez-footer .footer-content').should('exist');
    cy.get('ez-footer .footer-bottom').should('exist');
    
    // Check copyright year
    cy.get('ez-footer .footer-bottom').should('contain', new Date().getFullYear());
  });

  it('should render consistently on signup page', () => {
    // Visit signup page
    cy.visit('/signup.html');
    
    // Check footer exists
    cy.get('ez-footer').should('exist');
    
    // Check footer content
    cy.get('ez-footer .footer-content').should('exist');
    cy.get('ez-footer .footer-bottom').should('exist');
    
    // Check copyright year
    cy.get('ez-footer .footer-bottom').should('contain', new Date().getFullYear());
  });

  it('should render consistently on dashboard page', () => {
    // Set up mock authenticated user
    cy.window().then((win) => {
      localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { email: 'test@example.com' }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ email: 'test@example.com' }),
        getSites: cy.stub().resolves([])
      };
    });
    
    // Visit dashboard
    cy.visit('/dashboard.html');
    
    // Check footer exists
    cy.get('ez-footer').should('exist');
    
    // Check footer content
    cy.get('ez-footer .footer-content').should('exist');
    cy.get('ez-footer .footer-bottom').should('exist');
    
    // Check copyright year
    cy.get('ez-footer .footer-bottom').should('contain', new Date().getFullYear());
  });

  it('should have consistent footer links across pages', () => {
    // Visit homepage
    cy.visit('/');
    
    // Count footer links
    cy.get('ez-footer .footer-links a').its('length').then((homepageLinksCount) => {
      // Visit login page
      cy.visit('/login.html');
      
      // Check that it has the same number of links
      cy.get('ez-footer .footer-links a').should('have.length', homepageLinksCount);
      
      // Visit signup page
      cy.visit('/signup.html');
      
      // Check that it has the same number of links
      cy.get('ez-footer .footer-links a').should('have.length', homepageLinksCount);
    });
  });

  it('should navigate to correct pages when footer links are clicked', () => {
    // Visit homepage
    cy.visit('/');
    
    // Stub window.location.href
    cy.window().then((win) => {
      cy.stub(win.location, 'href').as('locationHref');
    });
    
    // Click on About link
    cy.get('ez-footer .footer-links a').contains('About').click();
    
    // Check that it would navigate to about page
    cy.get('@locationHref').should('contain', '/about.html');
  });

  it('should have consistent styling in light mode', () => {
    // Ensure light mode
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'false');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Get footer background color
    cy.get('ez-footer').invoke('css', 'background-color').then((footerColor) => {
      // Visit login page
      cy.visit('/login.html');
      
      // Check that footer has the same background color
      cy.get('ez-footer').should('have.css', 'background-color', footerColor);
    });
  });

  it('should have consistent styling in dark mode', () => {
    // Enable dark mode
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditDarkMode', 'true');
    });
    
    // Visit homepage
    cy.visit('/');
    
    // Get footer background color
    cy.get('ez-footer').invoke('css', 'background-color').then((footerColor) => {
      // Visit login page
      cy.visit('/login.html');
      
      // Check that footer has the same background color
      cy.get('ez-footer').should('have.css', 'background-color', footerColor);
    });
  });
});
