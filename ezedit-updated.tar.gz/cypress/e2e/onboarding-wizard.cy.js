/**
 * Onboarding Wizard Tests
 * Tests the step-by-step onboarding process for new users
 */

describe('Onboarding Wizard', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    cy.clearLocalStorage();
    
    // Visit homepage
    cy.visit('/');
  });

  it('should start onboarding from homepage signup button', () => {
    // Click signup button on homepage
    cy.get('.signup-btn').click();
    
    // Check that we're redirected to signup page
    cy.url().should('include', '/signup.html');
    
    // Check that onboarding progress is displayed
    cy.get('.onboarding-progress').should('be.visible');
    cy.get('.onboarding-step').should('have.length', 3);
    cy.get('.onboarding-step').eq(0).should('have.class', 'active');
    cy.get('.onboarding-step-title').eq(0).should('contain', 'Create Account');
  });

  it('should show step 1: signup form with validation', () => {
    // Go to signup page
    cy.visit('/signup.html');
    
    // Check that signup form is displayed
    cy.get('.signup-form').should('be.visible');
    
    // Check form fields
    cy.get('input[name="email"]').should('be.visible');
    cy.get('input[name="password"]').should('be.visible');
    cy.get('input[name="confirmPassword"]').should('be.visible');
    
    // Submit empty form
    cy.get('.signup-form .submit-btn').click();
    
    // Check for validation errors
    cy.get('.error-message').should('be.visible');
    
    // Fill with invalid email
    cy.get('input[name="email"]').type('invalid-email');
    cy.get('.signup-form .submit-btn').click();
    
    // Check for email validation error
    cy.get('.error-message').should('contain', 'valid email');
    
    // Fill with valid email but mismatched passwords
    cy.get('input[name="email"]').clear().type('user@example.com');
    cy.get('input[name="password"]').type('Password123!');
    cy.get('input[name="confirmPassword"]').type('DifferentPassword123!');
    cy.get('.signup-form .submit-btn').click();
    
    // Check for password match error
    cy.get('.error-message').should('contain', 'match');
  });

  it('should proceed to step 2: email verification after signup', () => {
    // Setup stub for Supabase signUp
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signUp: cy.stub().as('signUp').resolves({
          data: { user: { id: 'new-user-id', email: 'user@example.com' } },
          error: null
        })
      };
    });
    
    // Go to signup page
    cy.visit('/signup.html');
    
    // Fill signup form
    cy.get('input[name="email"]').type('user@example.com');
    cy.get('input[name="password"]').type('Password123!');
    cy.get('input[name="confirmPassword"]').type('Password123!');
    
    // Submit form
    cy.get('.signup-form .submit-btn').click();
    
    // Check that signUp was called with correct parameters
    cy.get('@signUp').should('be.calledWith', {
      email: 'user@example.com',
      password: 'Password123!'
    });
    
    // Check that we're on verification step
    cy.get('.onboarding-step').eq(0).should('have.class', 'completed');
    cy.get('.onboarding-step').eq(1).should('have.class', 'active');
    cy.get('.onboarding-step-title').eq(1).should('contain', 'Verify Email');
    
    // Check verification instructions
    cy.get('.verification-instructions').should('be.visible');
    cy.get('.verification-instructions').should('contain', 'user@example.com');
    cy.get('.resend-email-btn').should('be.visible');
  });

  it('should handle email verification and proceed to step 3', () => {
    // Setup authenticated user but not verified
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'new-user-id', 
          email: 'user@example.com',
          email_confirmed_at: null
        }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ 
          email: 'user@example.com', 
          id: 'new-user-id',
          email_confirmed_at: null
        }),
        checkEmailVerification: cy.stub().as('checkEmailVerification').resolves({
          data: { 
            user: { 
              id: 'new-user-id', 
              email: 'user@example.com',
              email_confirmed_at: new Date().toISOString()
            }
          },
          error: null
        })
      };
    });
    
    // Go to verification page
    cy.visit('/verify-email.html');
    
    // Check that verification page is displayed
    cy.get('.verification-page').should('be.visible');
    
    // Click check verification button
    cy.get('.check-verification-btn').click();
    
    // Check that checkEmailVerification was called
    cy.get('@checkEmailVerification').should('be.called');
    
    // Check that we're redirected to step 3
    cy.url().should('include', '/onboarding.html');
    cy.get('.onboarding-step').eq(0).should('have.class', 'completed');
    cy.get('.onboarding-step').eq(1).should('have.class', 'completed');
    cy.get('.onboarding-step').eq(2).should('have.class', 'active');
    cy.get('.onboarding-step-title').eq(2).should('contain', 'First Site');
  });

  it('should allow resending verification email', () => {
    // Setup stub for resend verification
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'new-user-id', 
          email: 'user@example.com',
          email_confirmed_at: null
        }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ 
          email: 'user@example.com', 
          id: 'new-user-id',
          email_confirmed_at: null
        }),
        resendVerificationEmail: cy.stub().as('resendVerificationEmail').resolves({
          data: { success: true },
          error: null
        })
      };
    });
    
    // Go to verification page
    cy.visit('/verify-email.html');
    
    // Click resend email button
    cy.get('.resend-email-btn').click();
    
    // Check that resendVerificationEmail was called
    cy.get('@resendVerificationEmail').should('be.called');
    
    // Check for success toast
    cy.get('.toast-success').should('be.visible');
    cy.get('.toast-success').should('contain', 'Email sent');
  });

  it('should complete step 3: first site setup', () => {
    // Setup authenticated and verified user
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'new-user-id', 
          email: 'user@example.com',
          email_confirmed_at: new Date().toISOString()
        }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ 
          email: 'user@example.com', 
          id: 'new-user-id',
          email_confirmed_at: new Date().toISOString()
        }),
        addSite: cy.stub().as('addSite').resolves({
          data: {
            id: 'new-site-id',
            name: 'My First Site',
            host: 'ftp.example.com',
            port: 21,
            username: 'ftpuser',
            passive: true,
            created_at: new Date().toISOString()
          },
          error: null
        })
      };
    });
    
    // Go to onboarding page
    cy.visit('/onboarding.html');
    
    // Check that first site form is displayed
    cy.get('.first-site-form').should('be.visible');
    
    // Fill form
    cy.get('input[name="name"]').type('My First Site');
    cy.get('input[name="host"]').type('ftp.example.com');
    cy.get('input[name="port"]').clear().type('21');
    cy.get('input[name="username"]').type('ftpuser');
    cy.get('input[name="password"]').type('password123');
    cy.get('input[name="passive"]').check();
    
    // Submit form
    cy.get('.first-site-form .submit-btn').click();
    
    // Check that addSite was called with correct parameters
    cy.get('@addSite').should('be.calledWith', {
      name: 'My First Site',
      host: 'ftp.example.com',
      port: 21,
      username: 'ftpuser',
      password: 'password123',
      passive: true,
      user_id: 'new-user-id'
    });
    
    // Check that we're redirected to dashboard
    cy.url().should('include', '/dashboard.html');
    
    // Check for success toast
    cy.get('.toast-success').should('be.visible');
    cy.get('.toast-success').should('contain', 'Onboarding complete');
    
    // Check that onboarding completed flag is set
    cy.window().then((win) => {
      const auth = JSON.parse(win.localStorage.getItem('ezEditAuth'));
      expect(auth.onboardingCompleted).to.be.true;
    });
  });

  it('should skip onboarding for returning users', () => {
    // Setup authenticated user with completed onboarding
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'existing-user-id', 
          email: 'user@example.com',
          email_confirmed_at: new Date().toISOString()
        },
        onboardingCompleted: true
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ 
          email: 'user@example.com', 
          id: 'existing-user-id',
          email_confirmed_at: new Date().toISOString()
        })
      };
    });
    
    // Try to visit onboarding page
    cy.visit('/onboarding.html');
    
    // Check that we're redirected to dashboard
    cy.url().should('include', '/dashboard.html');
  });

  it('should show helpful tooltips during onboarding', () => {
    // Setup authenticated and verified user
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'new-user-id', 
          email: 'user@example.com',
          email_confirmed_at: new Date().toISOString()
        }
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ 
          email: 'user@example.com', 
          id: 'new-user-id',
          email_confirmed_at: new Date().toISOString()
        })
      };
    });
    
    // Go to onboarding page
    cy.visit('/onboarding.html');
    
    // Check that help button is displayed
    cy.get('.help-btn').should('be.visible');
    
    // Click help button
    cy.get('.help-btn').click();
    
    // Check that tooltip is displayed
    cy.get('.onboarding-tooltip').should('be.visible');
    cy.get('.onboarding-tooltip').should('contain', 'FTP credentials');
    
    // Click next tooltip button
    cy.get('.next-tooltip-btn').click();
    
    // Check that next tooltip is displayed
    cy.get('.onboarding-tooltip').should('contain', 'passive mode');
    
    // Close tooltip
    cy.get('.close-tooltip-btn').click();
    
    // Check that tooltip is closed
    cy.get('.onboarding-tooltip').should('not.exist');
  });

  it('should handle errors during onboarding steps', () => {
    // Setup stub for Supabase signUp with error
    cy.window().then((win) => {
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        signUp: cy.stub().as('signUp').resolves({
          data: null,
          error: { message: 'Email already in use' }
        })
      };
    });
    
    // Go to signup page
    cy.visit('/signup.html');
    
    // Fill signup form
    cy.get('input[name="email"]').type('existing@example.com');
    cy.get('input[name="password"]').type('Password123!');
    cy.get('input[name="confirmPassword"]').type('Password123!');
    
    // Submit form
    cy.get('.signup-form .submit-btn').click();
    
    // Check for error toast
    cy.get('.toast-error').should('be.visible');
    cy.get('.toast-error').should('contain', 'Email already in use');
    
    // Check that we're still on signup step
    cy.get('.onboarding-step').eq(0).should('have.class', 'active');
    cy.get('.onboarding-step').eq(0).should('not.have.class', 'completed');
  });

  it('should provide a link to documentation during onboarding', () => {
    // Go to signup page
    cy.visit('/signup.html');
    
    // Check that docs link is displayed
    cy.get('.docs-link').should('be.visible');
    cy.get('.docs-link').should('have.attr', 'href').and('include', '/docs');
    
    // Check that docs link opens in new tab
    cy.get('.docs-link').should('have.attr', 'target', '_blank');
  });

  it('should persist onboarding progress between page reloads', () => {
    // Setup authenticated user at verification step
    cy.window().then((win) => {
      win.localStorage.setItem('ezEditAuth', JSON.stringify({
        isAuthenticated: true,
        user: { 
          id: 'new-user-id', 
          email: 'user@example.com',
          email_confirmed_at: null
        },
        onboardingStep: 1 // Verification step
      }));
      
      win.ezEdit = win.ezEdit || {};
      win.ezEdit.supabase = {
        isAuthenticated: cy.stub().returns(true),
        getUser: cy.stub().returns({ 
          email: 'user@example.com', 
          id: 'new-user-id',
          email_confirmed_at: null
        })
      };
    });
    
    // Go to homepage
    cy.visit('/');
    
    // Check that we're redirected to verification page
    cy.url().should('include', '/verify-email.html');
    
    // Check that onboarding progress shows step 2 active
    cy.get('.onboarding-step').eq(0).should('have.class', 'completed');
    cy.get('.onboarding-step').eq(1).should('have.class', 'active');
  });
});
