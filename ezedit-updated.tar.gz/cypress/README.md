# ezEdit UI Testing Framework

This directory contains the Cypress end-to-end testing framework for the ezEdit application. These tests ensure UI consistency, authentication flows, and core functionality work correctly across all pages.

## Test Suite Structure

The ezEdit Cypress test suite is organized as follows:

- `cypress/e2e/` - Contains all end-to-end test files
  - `ui-auth-consistency.cy.js` - Tests for UI consistency across authenticated and unauthenticated states
  - `login-functionality.cy.js` - Tests for login form validation and submission
  - `dashboard-functionality.cy.js` - Tests for dashboard features and layout
  - `theme-toggle.cy.js` - Tests for dark/light theme toggle functionality
  - `toast-notifications.cy.js` - Tests for toast notification system
  - `header-footer-components.cy.js` - Tests for header and footer web components
  - `auth-flow.cy.js` - Tests for complete authentication flow including signup, login, OAuth, and session management
  - `site-management.cy.js` - Tests for adding, editing, and deleting FTP sites
  - `code-editor.cy.js` - Tests for Monaco editor integration, diff view, and code editing functionality
  - `subscription-payment.cy.js` - Tests for Stripe integration, subscription plans, and payment flows
  - `onboarding-wizard.cy.js` - Tests for the step-by-step onboarding process for new users

## Running Tests

### Local Development

To run the tests locally:

```bash
# Install dependencies if you haven't already
pnpm install

# Run all tests in headless mode
node run-ui-tests.js

# Run specific test files
npx cypress run --spec "cypress/e2e/login-functionality.cy.js"

# Open Cypress Test Runner UI
npx cypress open
```

### CI/CD Pipeline

Tests automatically run on GitHub Actions when:
- Pull requests are opened against the main branch
- Code is pushed to the main branch
- Manually triggered from GitHub Actions UI

The workflow is defined in `.github/workflows/ui-tests.yml`.

## Test Reports

After running tests, reports are generated in:
- `cypress/reports/test-summary.json`: JSON summary of test results
- `cypress/reports/test-report.html`: HTML report with detailed results

## Adding New Tests

When adding new tests:

1. Create a new file in `cypress/e2e/` with the `.cy.js` extension
2. Follow the existing patterns for test organization
3. Add the new test file to the `run-ui-tests.js` script
4. Run the tests locally to verify they work

## Best Practices

- Test selectors should use data attributes when possible (`data-testid="login-button"`)
- Mock external dependencies like Supabase authentication
- Test both light and dark mode variants
- Verify UI consistency across all pages
- Test error states and edge cases

## Common Test Utilities

Common test utilities and fixtures are available in:
- `cypress/support/commands.js`: Custom Cypress commands
- `cypress/fixtures/`: Test data files

## Troubleshooting

If tests are failing:

1. Check that the local server is running on port 3000
2. Verify that test selectors match the current UI components
3. Check for changes in authentication flows or API responses
4. Run tests in open mode to visually debug: `npx cypress open`
